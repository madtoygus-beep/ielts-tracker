import { useState, useEffect } from 'react'
import { auth, db } from '../firebase'
import {
  collection,
  addDoc,
  query,
  where,
  onSnapshot,
  doc,
  updateDoc,
  deleteDoc
} from 'firebase/firestore'
import { signOut, onAuthStateChanged, updatePassword } from 'firebase/auth'
import { useNavigate } from 'react-router-dom'

const letters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ'.split('')

export default function TeacherDashboard() {
  const [students, setStudents] = useState([])
  const [scores, setScores] = useState({})

  const [readings, setReadings] = useState([])
  const [submissions, setSubmissions] = useState([])

  const [writings, setWritings] = useState([])
  const [writingSubmissions, setWritingSubmissions] = useState([])

  const [listenings, setListenings] = useState([])
  const [listeningSubmissions, setListeningSubmissions] = useState([])

  const [mockTests, setMockTests] = useState([])
  const [mockSubmissions, setMockSubmissions] = useState([])
  
  const [readingLibraryFilter, setReadingLibraryFilter] = useState('active')
  const [writingLibraryFilter, setWritingLibraryFilter] = useState('active')
  const [listeningLibraryFilter, setListeningLibraryFilter] = useState('active')

  const [selected, setSelected] = useState(null)
  const [selectedStudentSection, setSelectedStudentSection] = useState('scores')
  const [selectedReview, setSelectedReview] = useState(null)

  const [selectedHomework, setSelectedHomework] = useState(null)
  const [selectedHomeworkType, setSelectedHomeworkType] = useState(null)
  const [assignmentDraft, setAssignmentDraft] = useState([])

  const [selectedWritingReview, setSelectedWritingReview] = useState(null)
  const [selectedMockWritingReview, setSelectedMockWritingReview] = useState(null)
  const [writingReviewForm, setWritingReviewForm] = useState({
    task1Band: '',
    task2Band: '',
    task1TA: '',
    task1CC: '',
    task1LR: '',
    task1GRA: '',
    task2TR: '',
    task2CC: '',
    task2LR: '',
    task2GRA: '',
    task1Feedback: '',
    task2Feedback: '',
    overall: '',
    generalFeedback: ''
  })

  const [form, setForm] = useState({
    listening: '',
    reading: '',
    writing: '',
    speaking: '',
    date: ''
  })

  const [user, setUser] = useState(null)
  const [showPasswordModal, setShowPasswordModal] = useState(false)
  const [newPassword, setNewPassword] = useState('')
  const [passwordMsg, setPasswordMsg] = useState('')
  const [activeTab, setActiveTab] = useState('overview')

  const navigate = useNavigate()

  useEffect(() => {
    const liveUnsubscribers = []

    const clearLiveUnsubscribers = () => {
      while (liveUnsubscribers.length > 0) {
        const unsubscribe = liveUnsubscribers.pop()

        if (typeof unsubscribe === 'function') {
          unsubscribe()
        }
      }
    }

    const trackSnapshot = unsubscribe => {
      liveUnsubscribers.push(unsubscribe)
      return unsubscribe
    }

    const unsubAuth = onAuthStateChanged(auth, currentUser => {
      clearLiveUnsubscribers()

      if (!currentUser) {
        navigate('/login')
        return
      }

      setUser(currentUser)

      const studentsQuery = query(
        collection(db, 'users'),
        where('role', '==', 'student')
      )

      trackSnapshot(
        onSnapshot(studentsQuery, snap => {
          const list = snap.docs
          .map(d => ({ id: d.id, ...d.data() }))
          .filter(u => !u.deleted && u.status === 'approved')
          setStudents(list)
        })
      )

      trackSnapshot(
        onSnapshot(collection(db, 'scores'), snap => {
          const groupedScores = {}

          snap.docs.forEach(scoreDoc => {
            const score = {
              id: scoreDoc.id,
              ...scoreDoc.data()
            }

            if (!score.uid) return

            if (!groupedScores[score.uid]) {
              groupedScores[score.uid] = []
            }

            groupedScores[score.uid].push(score)
          })

          Object.keys(groupedScores).forEach(studentId => {
            groupedScores[studentId].sort(
              (a, b) => new Date(b.date || 0) - new Date(a.date || 0)
            )
          })

          setScores(groupedScores)
        })
      )

      trackSnapshot(
        onSnapshot(query(collection(db, 'readings')), snap => {
          const list = snap.docs.map(d => ({ id: d.id, ...d.data() }))
          list.sort((a, b) => new Date(b.createdAt || 0) - new Date(a.createdAt || 0))
          setReadings(list)
        })
      )

      trackSnapshot(
        onSnapshot(query(collection(db, 'readingSubmissions')), snap => {
          setSubmissions(snap.docs.map(d => ({ id: d.id, ...d.data() })))
        })
      )

      trackSnapshot(
        onSnapshot(query(collection(db, 'writingHomeworks')), snap => {
          const list = snap.docs.map(d => ({ id: d.id, ...d.data() }))
          list.sort((a, b) => new Date(b.createdAt || 0) - new Date(a.createdAt || 0))
          setWritings(list)
        })
      )

      trackSnapshot(
        onSnapshot(query(collection(db, 'writingSubmissions')), snap => {
          setWritingSubmissions(snap.docs.map(d => ({ id: d.id, ...d.data() })))
        })
      )

      trackSnapshot(
        onSnapshot(query(collection(db, 'listenings')), snap => {
          const list = snap.docs.map(d => ({ id: d.id, ...d.data() }))
          list.sort((a, b) => new Date(b.createdAt || 0) - new Date(a.createdAt || 0))
          setListenings(list)
        })
      )

      trackSnapshot(
        onSnapshot(query(collection(db, 'listeningSubmissions')), snap => {
          setListeningSubmissions(snap.docs.map(d => ({ id: d.id, ...d.data() })))
        })
      )

      trackSnapshot(
        onSnapshot(query(collection(db, 'mockTests')), snap => {
          const list = snap.docs.map(d => ({ id: d.id, ...d.data() }))
          list.sort((a, b) => new Date(b.createdAt || 0) - new Date(a.createdAt || 0))
          setMockTests(list)
        })
      )

      trackSnapshot(
        onSnapshot(query(collection(db, 'mockSubmissions')), snap => {
          setMockSubmissions(snap.docs.map(d => ({ id: d.id, ...d.data() })))
        })
      )
    })

    return () => {
      unsubAuth()
      clearLiveUnsubscribers()
    }
  }, [navigate])

  const activeReadings = readings.filter(r => !r.archived)
  const archivedReadings = readings.filter(r => r.archived)

  const activeWritings = writings.filter(w => !w.archived)
  const archivedWritings = writings.filter(w => w.archived)

  const activeListenings = listenings.filter(l => !l.archived)
  const archivedListenings = listenings.filter(l => l.archived)
  

  const overall = score => {
    const avg =
      (+score.listening +
        +score.reading +
        +score.writing +
        +score.speaking) /
      4

    return (Math.round(avg * 2) / 2).toFixed(1)
  }

  const handleAddScore = async () => {
    if (
      !form.listening ||
      !form.reading ||
      !form.writing ||
      !form.speaking ||
      !form.date
    ) {
      return
    }

    await addDoc(collection(db, 'scores'), {
      ...form,
      uid: selected.id,
      overall: overall(form),
      addedBy: user.uid
    })

    setForm({
      listening: '',
      reading: '',
      writing: '',
      speaking: '',
      date: ''
    })
  }

  const latestScore = studentId => scores[studentId]?.[0]

  const getStudentReadings = studentId => {
    return activeReadings.filter(reading =>
      reading.assignTo?.includes(studentId)
    )
  }

  const getStudentWritings = studentId => {
    return activeWritings.filter(writing =>
      writing.assignTo?.includes(studentId)
    )
  }

  const getStudentListenings = studentId => {
    return activeListenings.filter(listening =>
      listening.assignTo?.includes(studentId)
    )
  }

  const getSubmission = (studentId, readingId) => {
    return submissions.find(
      sub => sub.uid === studentId && sub.readingId === readingId
    )
  }

  const getWritingSubmission = (studentId, writingId) => {
    return writingSubmissions.find(
      sub => sub.uid === studentId && sub.writingId === writingId
    )
  }

  const getListeningSubmission = (studentId, listeningId) => {
    return listeningSubmissions.find(
      sub => sub.uid === studentId && sub.listeningId === listeningId
    )
  }

  const getCompletedCount = readingId => {
    return submissions.filter(sub => sub.readingId === readingId).length
  }

  const getWritingSubmittedCount = writingId => {
    return writingSubmissions.filter(sub => sub.writingId === writingId).length
  }

  const getWritingReviewedCount = writingId => {
    return writingSubmissions.filter(
      sub => sub.writingId === writingId && sub.reviewed
    ).length
  }

  const getListeningCompletedCount = listeningId => {
    return listeningSubmissions.filter(sub => sub.listeningId === listeningId).length
  }

  const pendingReviewWritings = activeWritings.filter(writing => {
    const submitted = getWritingSubmittedCount(writing.id)
    const reviewed = getWritingReviewedCount(writing.id)

    return submitted > reviewed
  })

  const pendingWritingReviews = writingSubmissions
    .filter(submission => !submission.reviewed)
    .map(submission => {
      const student = students.find(item => item.id === submission.uid)
      const writing = writings.find(item => item.id === submission.writingId)

      if (!student || !writing) return null

      return {
        submission,
        student,
        writing
      }
    })
    .filter(Boolean)
    .sort((a, b) =>
      new Date(b.submission.submittedAt || 0) -
      new Date(a.submission.submittedAt || 0)
    )

  const getMockWritingStatus = submission => {
    return (
      submission.result?.writing?.status ||
      submission.writingReview?.status ||
      submission.review?.writingStatus ||
      'pending_review'
    )
  }

  const getMockTask1Answer = submission => {
    return (
      submission.writingAnswers?.task1 ||
      submission.writing?.task1 ||
      submission.task1Answer ||
      ''
    )
  }

  const getMockTask2Answer = submission => {
    return (
      submission.writingAnswers?.task2 ||
      submission.writing?.task2 ||
      submission.task2Answer ||
      ''
    )
  }

  const getMockTask1WordCount = submission => {
    return (
      submission.result?.writing?.task1WordCount ||
      submission.writing?.task1WordCount ||
      submission.task1WordCount ||
      getWordCount(getMockTask1Answer(submission))
    )
  }

  const getMockTask2WordCount = submission => {
    return (
      submission.result?.writing?.task2WordCount ||
      submission.writing?.task2WordCount ||
      submission.task2WordCount ||
      getWordCount(getMockTask2Answer(submission))
    )
  }

  const getMockWritingReview = submission => {
    return submission.result?.writing?.review || submission.writingReview || null
  }

  const pendingMockWritingReviews = mockSubmissions
    .filter(submission => {
      if (submission.archived) return false
      if (!getMockTask1Answer(submission) && !getMockTask2Answer(submission)) return false

      return getMockWritingStatus(submission) !== 'reviewed'
    })
    .map(submission => {
      const student = students.find(item => item.id === submission.uid)
      const mock = mockTests.find(item => item.id === submission.mockTestId)

      if (!student) return null

      return {
        submission,
        student,
        mock
      }
    })
    .filter(Boolean)
    .sort((a, b) =>
      new Date(b.submission.submittedAt || 0) -
      new Date(a.submission.submittedAt || 0)
    )

  const reviewedMockWritingCount = mockSubmissions.filter(
    submission => getMockWritingStatus(submission) === 'reviewed'
  ).length

  const submittedMockWritingCount = mockSubmissions.filter(
    submission => getMockTask1Answer(submission) || getMockTask2Answer(submission)
  ).length

  const totalPendingWritingReviews =
    pendingWritingReviews.length + pendingMockWritingReviews.length

  const reviewedWritingCount =
    writingSubmissions.filter(submission => submission.reviewed).length +
    reviewedMockWritingCount

  const submittedWritingCount =
    writingSubmissions.length + submittedMockWritingCount

  const formatDateShort = value => {
    if (!value) return 'No date'

    try {
      return new Date(value).toLocaleDateString()
    } catch (error) {
      return value
    }
  }

  const filteredReadings =
    readingLibraryFilter === 'all'
      ? readings
      : readingLibraryFilter === 'archived'
        ? archivedReadings
        : activeReadings

  const filteredWritings =
    writingLibraryFilter === 'all'
      ? writings
      : writingLibraryFilter === 'archived'
        ? archivedWritings
        : writingLibraryFilter === 'pending'
          ? pendingReviewWritings
          : activeWritings

  const filteredListenings =
    listeningLibraryFilter === 'all'
      ? listenings
      : listeningLibraryFilter === 'archived'
        ? archivedListenings
        : activeListenings

  const openAssignmentManager = (homework, type) => {
    setSelectedHomework(homework)
    setSelectedHomeworkType(type)
    setAssignmentDraft(homework.assignTo || [])
  }

  const toggleAssignment = studentId => {
    setAssignmentDraft(prev =>
      prev.includes(studentId)
        ? prev.filter(id => id !== studentId)
        : [...prev, studentId]
    )
  }

  const saveAssignments = async () => {
    if (!selectedHomework || !selectedHomeworkType) return

    const collectionName =
      selectedHomeworkType === 'reading'
        ? 'readings'
        : selectedHomeworkType === 'listening'
          ? 'listenings'
          : 'writingHomeworks'

    await updateDoc(doc(db, collectionName, selectedHomework.id), {
      assignTo: assignmentDraft,
      archived: false
    })

    setSelectedHomework(null)
    setSelectedHomeworkType(null)
    setAssignmentDraft([])
  }

  const archiveReadingHomework = async reading => {
    const ok = window.confirm(
      `"${reading.title}" will be archived and removed from students' homework list. Existing results will stay saved.`
    )

    if (!ok) return

    await updateDoc(doc(db, 'readings', reading.id), {
      archived: true,
      assignTo: []
    })
  }

  const restoreReadingHomework = async reading => {
    await updateDoc(doc(db, 'readings', reading.id), {
      archived: false
    })
  }

  const deleteReadingHomework = async reading => {
    const completedCount = getCompletedCount(reading.id)

    if (completedCount > 0) {
      const forceDelete = window.confirm(
        `"${reading.title}" has ${completedCount} student submission(s).

Deleting will permanently remove:
- Homework
- Student answers
- Results/Bands

Continue permanent delete?`
      )

      if (!forceDelete) return

      const relatedSubs = submissions.filter(
        sub => sub.readingId === reading.id
      )

      for (const sub of relatedSubs) {
        await deleteDoc(doc(db, 'readingSubmissions', sub.id))
      }

      await deleteDoc(doc(db, 'readings', reading.id))
      return
    }

    const ok = window.confirm(`Delete "${reading.title}" permanently?`)
    if (!ok) return

    await deleteDoc(doc(db, 'readings', reading.id))
  }

  const duplicateReadingHomework = async reading => {
    const ok = window.confirm(
      `Duplicate "${reading.title}"? The copy will not be assigned to any student.`
    )

    if (!ok) return

    const {
      id,
      createdAt,
      updatedAt,
      createdBy,
      assignTo,
      archived,
      ...copyData
    } = reading

    await addDoc(collection(db, 'readings'), {
      ...copyData,
      title: `${reading.title} Copy`,
      assignTo: [],
      archived: false,
      createdBy: user.uid,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    })
  }

  const archiveWritingHomework = async writing => {
    const ok = window.confirm(
      `"${writing.title}" will be archived and removed from students' writing homework list. Existing submissions will stay saved.`
    )

    if (!ok) return

    await updateDoc(doc(db, 'writingHomeworks', writing.id), {
      archived: true,
      assignTo: []
    })
  }

  const restoreWritingHomework = async writing => {
    await updateDoc(doc(db, 'writingHomeworks', writing.id), {
      archived: false
    })
  }

  const deleteWritingHomework = async writing => {
    const submittedCount = getWritingSubmittedCount(writing.id)

    if (submittedCount > 0) {
      const forceDelete = window.confirm(
        `"${writing.title}" has ${submittedCount} student submission(s).

Deleting will permanently remove:
- Writing homework
- Student Task 1 / Task 2 answers
- Teacher reviews

Continue permanent delete?`
      )

      if (!forceDelete) return

      const relatedSubs = writingSubmissions.filter(
        sub => sub.writingId === writing.id
      )

      for (const sub of relatedSubs) {
        await deleteDoc(doc(db, 'writingSubmissions', sub.id))
      }

      await deleteDoc(doc(db, 'writingHomeworks', writing.id))
      return
    }

    const ok = window.confirm(`Delete "${writing.title}" permanently?`)
    if (!ok) return

    await deleteDoc(doc(db, 'writingHomeworks', writing.id))
  }

  const duplicateWritingHomework = async writing => {
    const ok = window.confirm(
      `Duplicate "${writing.title}"? The copy will not be assigned to any student.`
    )

    if (!ok) return

    const {
      id,
      createdAt,
      updatedAt,
      createdBy,
      assignTo,
      archived,
      ...copyData
    } = writing

    await addDoc(collection(db, 'writingHomeworks'), {
      ...copyData,
      title: `${writing.title} Copy`,
      assignTo: [],
      archived: false,
      createdBy: user.uid,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    })
  }

  const archiveListeningHomework = async listening => {
    const ok = window.confirm(
      `"${listening.title}" will be archived and removed from students' listening homework list. Existing results will stay saved.`
    )

    if (!ok) return

    await updateDoc(doc(db, 'listenings', listening.id), {
      archived: true,
      assignTo: []
    })
  }

  const restoreListeningHomework = async listening => {
    await updateDoc(doc(db, 'listenings', listening.id), {
      archived: false
    })
  }

  const deleteListeningHomework = async listening => {
    const completedCount = getListeningCompletedCount(listening.id)

    if (completedCount > 0) {
      const forceDelete = window.confirm(
        `"${listening.title}" has ${completedCount} student submission(s).

Deleting will permanently remove:
- Listening homework
- Student answers
- Results/Bands

Continue permanent delete?`
      )

      if (!forceDelete) return

      const relatedSubs = listeningSubmissions.filter(
        sub => sub.listeningId === listening.id
      )

      for (const sub of relatedSubs) {
        await deleteDoc(doc(db, 'listeningSubmissions', sub.id))
      }

      await deleteDoc(doc(db, 'listenings', listening.id))
      return
    }

    const ok = window.confirm(`Delete "${listening.title}" permanently?`)
    if (!ok) return

    await deleteDoc(doc(db, 'listenings', listening.id))
  }

  const duplicateListeningHomework = async listening => {
    const ok = window.confirm(
      `Duplicate "${listening.title}"? The copy will not be assigned to any student.`
    )

    if (!ok) return

    const {
      id,
      createdAt,
      updatedAt,
      createdBy,
      assignTo,
      archived,
      ...copyData
    } = listening

    await addDoc(collection(db, 'listenings'), {
      ...copyData,
      title: `${listening.title} Copy`,
      assignTo: [],
      archived: false,
      createdBy: user.uid,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    })
  }

  const numberWords = {
    zero: '0', one: '1', two: '2', three: '3', four: '4', five: '5',
    six: '6', seven: '7', eight: '8', nine: '9', ten: '10', eleven: '11',
    twelve: '12', thirteen: '13', fourteen: '14', fifteen: '15', sixteen: '16',
    seventeen: '17', eighteen: '18', nineteen: '19', twenty: '20'
  }

  const normalize = value => {
    if (value === undefined || value === null) return ''

    const clean = value
      .toString()
      .trim()
      .toLowerCase()
      .replace(/[.,!?;:()]/g, '')
      .replace(/\s+/g, ' ')

    return numberWords[clean] || clean
  }

  const getWordCount = value => {
    const clean = normalize(value)
    if (!clean) return 0
    return clean.split(' ').filter(Boolean).length
  }

  const parseAcceptedAnswers = cell => {
    const main = cell.answer ? [cell.answer] : []
    const alternatives = cell.acceptedAnswers
      ? cell.acceptedAnswers.split(',').map(item => item.trim()).filter(Boolean)
      : []

    return [...main, ...alternatives]
  }

  const isWithinWordLimit = (value, maxWords) => {
    if (!maxWords) return true
    return getWordCount(value) <= Number(maxWords)
  }

  const sortAnswers = value => {
    if (!Array.isArray(value)) return []
    return [...value].map(v => v?.toString().trim()).sort()
  }

  const tableAnswerKey = (questionId, rowId, cellIndex) => {
    return `${questionId}_${rowId}_${cellIndex}`
  }

  const getHeadingText = (reading, number) => {
    if (!number) return 'No answer'
    const index = Number(number) - 1
    return reading.headings?.[index] || `Heading ${number}`
  }

  const getOptionText = (question, letter) => {
    if (!letter) return ''
    const index = letters.indexOf(letter)
    return question.options?.[index] || ''
  }

  const getAnswerText = (question, value) => {
    if (question.type === 'mcq') {
      if (Array.isArray(value)) {
        if (value.length === 0) return 'No answer'
        return value
          .map(letter => `${letter}. ${getOptionText(question, letter)}`)
          .join(', ')
      }

      if (!value) return 'No answer'
      return `${value}. ${getOptionText(question, value)}`
    }

    if (Array.isArray(value)) {
      if (value.length === 0) return 'No answer'
      return value.join(', ')
    }

    return value || 'No answer'
  }

  const isNormalCorrect = (submission, question) => {
    if (question.type === 'mcq' && question.mode === 'multi') {
      const userAnswer = sortAnswers(submission.answers?.[question.id]).join('|')
      const correctAnswer = sortAnswers(question.answers || []).join('|')

      return userAnswer === correctAnswer
    }

    const userAnswer = normalize(submission.answers?.[question.id])
    const correctAnswer = normalize(question.answer)

    return userAnswer === correctAnswer
  }

  const isMatchingCorrect = (submission, question, paragraph) => {
    const userAnswer = submission.answers?.[question.id]?.[paragraph.letter]
      ?.toString()
      .trim()

    const correctAnswer = paragraph.answer?.toString().trim()

    return userAnswer === correctAnswer
  }

  const isSentenceEndingCorrect = (submission, question, item) => {
    const userAnswer = submission.answers?.[question.id]?.[item.id]
      ?.toString()
      .trim()

    const correctAnswer = item.answer?.toString().trim()

    return userAnswer === correctAnswer
  }

  const getSentenceEndingText = (question, letter) => {
    if (!letter) return 'No answer'

    const index = letters.indexOf(letter)

    return question.endings?.[index] || `Ending ${letter}`
  }

  const isTableCellCorrect = (submission, question, row, cellIndex) => {
    const key = tableAnswerKey(question.id, row.id, cellIndex)
    const cell = row.cells[cellIndex]
    const userAnswer = normalize(submission.answers?.[key])
    const acceptedAnswers = parseAcceptedAnswers(cell).map(normalize)

    if (!isWithinWordLimit(submission.answers?.[key], cell.maxWords)) return false

    return acceptedAnswers.includes(userAnswer)
  }

  const getStudentAnalytics = studentId => {
    const studentSubs = submissions.filter(sub => sub.uid === studentId)

    const stats = {
      matching: { correct: 0, total: 0 },
      sentenceEndings: { correct: 0, total: 0 },
      tfng: { correct: 0, total: 0 },
      fitb: { correct: 0, total: 0 },
      table: { correct: 0, total: 0 },
      summary: { correct: 0, total: 0 },
      note: { correct: 0, total: 0 },
      mcq: { correct: 0, total: 0 }
    }

    studentSubs.forEach(sub => {
      const reading = readings.find(r => r.id === sub.readingId)
      if (!reading) return

      reading.questions?.forEach(question => {
        if (question.type === 'matching') {
          question.paragraphs?.forEach(paragraph => {
            stats.matching.total++

            if (isMatchingCorrect(sub, question, paragraph)) {
              stats.matching.correct++
            }
          })

          return
        }

        if (question.type === 'sentenceEndings') {
          question.items?.forEach(item => {
            stats.sentenceEndings.total++

            if (isSentenceEndingCorrect(sub, question, item)) {
              stats.sentenceEndings.correct++
            }
          })

          return
        }

        if (question.type === 'sentenceEndings') {
          question.items?.forEach(item => {
            stats[key].total++

            if (!isSentenceEndingCorrect(submission, question, item)) {
              stats[key].wrong++
            }
          })

          return
        }

        if (question.type === 'table' || question.type === 'summary' || question.type === 'note') {
          question.rows?.forEach(row => {
            row.cells?.forEach((cell, cellIndex) => {
              if (cell.type === 'blank') {
                stats.table.total++

                if (isTableCellCorrect(sub, question, row, cellIndex)) {
                  stats.table.correct++
                }
              }
            })
          })

          return
        }

        if (!stats[question.type]) return

        stats[question.type].total++

        if (isNormalCorrect(sub, question)) {
          stats[question.type].correct++
        }
      })
    })

    const percentage = item =>
      item.total ? Math.round((item.correct / item.total) * 100) : null

    const data = {
      matching: percentage(stats.matching),
      sentenceEndings: percentage(stats.sentenceEndings),
      tfng: percentage(stats.tfng),
      fitb: percentage(stats.fitb),
      table: percentage(stats.table),
      summary: percentage(stats.summary),
      note: percentage(stats.note),
      mcq: percentage(stats.mcq)
    }

    const weaknessList = Object.entries(data)
      .filter(([, value]) => value !== null)
      .sort((a, b) => a[1] - b[1])

    return {
      ...data,
      weakest: weaknessList[0]?.[0] || null
    }
  }

  const getWeakestLabel = type => {
    if (type === 'matching') return 'Matching Headings'
    if (type === 'sentenceEndings') return 'Sentence Endings'
    if (type === 'tfng') return 'True / False / Not Given'
    if (type === 'fitb') return 'Fill in the Blank'
    if (type === 'table') return 'Table Completion'
    if (type === 'summary') return 'Summary Completion'
    if (type === 'note') return 'Note Completion'
    if (type === 'mcq') return 'Multiple Choice'
    return 'No data yet'
  }

  const getAnalyticsColor = value => {
    if (value === null || value === undefined) return 'text-gray-400'
    if (value >= 75) return 'text-green-600'
    if (value >= 60) return 'text-amber-600'
    return 'text-red-500'
  }




  const estimateReadingBand = (correct, total) => {
    if (!total) return null

    const percentage = (correct / total) * 100

    if (percentage >= 90) return 9
    if (percentage >= 85) return 8.5
    if (percentage >= 80) return 8
    if (percentage >= 75) return 7.5
    if (percentage >= 70) return 7
    if (percentage >= 65) return 6.5
    if (percentage >= 60) return 6
    if (percentage >= 50) return 5.5
    if (percentage >= 40) return 5
    if (percentage >= 30) return 4.5
    if (percentage >= 20) return 4
    return 3.5
  }

  const getReadingSubmissionResult = submission => {
    const reading = readings.find(item => item.id === submission.readingId)
    if (!reading) return null

    let correct = 0
    let total = 0

    reading.questions?.forEach(question => {
      if (question.type === 'matching') {
        question.paragraphs?.forEach(paragraph => {
          total++

          if (isMatchingCorrect(submission, question, paragraph)) {
            correct++
          }
        })

        return
      }

      if (question.type === 'sentenceEndings') {
        question.items?.forEach(item => {
          total++

          if (isSentenceEndingCorrect(submission, question, item)) {
            correct++
          }
        })

        return
      }

      if (question.type === 'table' || question.type === 'summary' || question.type === 'note') {
        question.rows?.forEach(row => {
          row.cells?.forEach((cell, cellIndex) => {
            if (cell.type === 'blank') {
              total++

              if (isTableCellCorrect(submission, question, row, cellIndex)) {
                correct++
              }
            }
          })
        })

        return
      }

      total++

      if (isNormalCorrect(submission, question)) {
        correct++
      }
    })

    return {
      correct,
      total,
      accuracy: total ? Math.round((correct / total) * 100) : null,
      estimatedBand: estimateReadingBand(correct, total)
    }
  }

  const getAverageReadingEstimatedBand = () => {
    const bands = submissions
      .map(submission => {
        if (submission.result?.band) return Number(submission.result.band)
        if (submission.result?.estimatedBand) return Number(submission.result.estimatedBand)

        const result = getReadingSubmissionResult(submission)
        return result?.estimatedBand
      })
      .filter(value => !Number.isNaN(value) && value > 0)

    if (bands.length === 0) return null

    const avg = bands.reduce((sum, value) => sum + value, 0) / bands.length
    return (Math.round(avg * 10) / 10).toFixed(1)
  }

  const getReadingCompletionStats = () => {
    const assigned = activeReadings.reduce(
      (sum, reading) => sum + (reading.assignTo?.length || 0),
      0
    )

    const activeReadingIds = activeReadings.map(reading => reading.id)

    const completed = submissions.filter(submission =>
      activeReadingIds.includes(submission.readingId)
    ).length

    const rate = assigned ? Math.round((completed / assigned) * 100) : 0

    return {
      assigned,
      completed,
      rate
    }
  }

  const getMostMissedReadingQuestions = () => {
    const stats = {}

    submissions.forEach(submission => {
      const reading = readings.find(item => item.id === submission.readingId)
      if (!reading) return

      reading.questions?.forEach((question, questionIndex) => {
        const key = `${reading.title} — Q${questionIndex + 1}`

        if (!stats[key]) {
          stats[key] = {
            label: key,
            wrong: 0,
            total: 0
          }
        }

        if (question.type === 'matching') {
          question.paragraphs?.forEach(paragraph => {
            stats[key].total++

            if (!isMatchingCorrect(submission, question, paragraph)) {
              stats[key].wrong++
            }
          })

          return
        }

        if (question.type === 'table' || question.type === 'summary' || question.type === 'note') {
          question.rows?.forEach(row => {
            row.cells?.forEach((cell, cellIndex) => {
              if (cell.type === 'blank') {
                stats[key].total++

                if (!isTableCellCorrect(submission, question, row, cellIndex)) {
                  stats[key].wrong++
                }
              }
            })
          })

          return
        }

        stats[key].total++

        if (!isNormalCorrect(submission, question)) {
          stats[key].wrong++
        }
      })
    })

    return Object.values(stats)
      .filter(item => item.total > 0)
      .map(item => ({
        ...item,
        wrongRate: Math.round((item.wrong / item.total) * 100)
      }))
      .sort((a, b) => b.wrongRate - a.wrongRate)
      .slice(0, 5)
  }

  const getAtRiskReadingStudents = () => {
    return students
      .map(student => {
        const studentSubs = submissions
          .filter(sub => sub.uid === student.id)
          .sort(
            (a, b) =>
              new Date(b.submittedAt || 0) - new Date(a.submittedAt || 0)
          )

        const latest = studentSubs[0]

        if (!latest) return null

        const result = latest.result?.band
          ? {
              estimatedBand: Number(latest.result.band),
              accuracy: latest.result.accuracy || null
            }
          : getReadingSubmissionResult(latest)

        if (!result?.estimatedBand) return null

        return {
          student,
          latestBand: Number(result.estimatedBand),
          latestAccuracy: result.accuracy,
          submissions: studentSubs.length
        }
      })
      .filter(item => item && item.latestBand < 6)
      .sort((a, b) => a.latestBand - b.latestBand)
      .slice(0, 5)
  }

  const getReadingTypeAnalytics = () => {
    const stats = {
      matching: { correct: 0, total: 0 },
      sentenceEndings: { correct: 0, total: 0 },
      mcq: { correct: 0, total: 0 },
      fitb: { correct: 0, total: 0 },
      tfng: { correct: 0, total: 0 },
      table: { correct: 0, total: 0 },
      summary: { correct: 0, total: 0 },
      note: { correct: 0, total: 0 }
    }

    submissions.forEach(submission => {
      const reading = readings.find(item => item.id === submission.readingId)
      if (!reading) return

      reading.questions?.forEach(question => {
        if (question.type === 'matching') {
          question.paragraphs?.forEach(paragraph => {
            stats.matching.total++

            if (isMatchingCorrect(submission, question, paragraph)) {
              stats.matching.correct++
            }
          })

          return
        }

        if (question.type === 'sentenceEndings') {
          question.items?.forEach(item => {
            stats.sentenceEndings.total++

            if (isSentenceEndingCorrect(submission, question, item)) {
              stats.sentenceEndings.correct++
            }
          })

          return
        }

        if (question.type === 'table' || question.type === 'summary' || question.type === 'note') {
          const key = question.type === 'summary'
            ? 'summary'
            : question.type === 'note'
              ? 'note'
              : 'table'

          question.rows?.forEach(row => {
            row.cells?.forEach((cell, cellIndex) => {
              if (cell.type === 'blank') {
                stats[key].total++

                if (isTableCellCorrect(submission, question, row, cellIndex)) {
                  stats[key].correct++
                }
              }
            })
          })

          return
        }

        if (!stats[question.type]) return

        stats[question.type].total++

        if (isNormalCorrect(submission, question)) {
          stats[question.type].correct++
        }
      })
    })

    return Object.entries(stats).map(([key, value]) => ({
      key,
      correct: value.correct,
      total: value.total,
      percentage: value.total
        ? Math.round((value.correct / value.total) * 100)
        : null
    }))
  }

  const getReadingTypeLabel = type => {
    if (type === 'matching') return 'Matching Headings'
    if (type === 'sentenceEndings') return 'Sentence Endings'
    if (type === 'mcq') return 'MCQ'
    if (type === 'fitb') return 'Fill Blank'
    if (type === 'tfng') return 'T/F/NG'
    if (type === 'table') return 'Table Completion'
    if (type === 'summary') return 'Summary Completion'
    if (type === 'note') return 'Note Completion'
    return type
  }


  const getAverageListeningBand = () => {
    const bands = listeningSubmissions
      .map(sub => Number(sub.result?.band))
      .filter(value => !Number.isNaN(value) && value > 0)

    if (bands.length === 0) return null

    const avg = bands.reduce((sum, value) => sum + value, 0) / bands.length
    return (Math.round(avg * 10) / 10).toFixed(1)
  }

  const getListeningCompletionStats = () => {
    const assigned = activeListenings.reduce(
      (sum, listening) => sum + (listening.assignTo?.length || 0),
      0
    )

    const activeListeningIds = activeListenings.map(listening => listening.id)

    const completed = listeningSubmissions.filter(submission =>
      activeListeningIds.includes(submission.listeningId)
    ).length

    const rate = assigned ? Math.round((completed / assigned) * 100) : 0

    return {
      assigned,
      completed,
      rate
    }
  }

  const getMostMissedListeningQuestions = () => {
    const stats = {}

    listeningSubmissions.forEach(submission => {
      const listening = listenings.find(item => item.id === submission.listeningId)
      if (!listening) return

      listening.questions?.forEach((question, questionIndex) => {
        const key = `${listening.title} — Q${questionIndex + 1}`

        if (!stats[key]) {
          stats[key] = {
            label: key,
            wrong: 0,
            total: 0
          }
        }

        if (question.type === 'table' || question.type === 'summary' || question.type === 'note') {
          question.rows?.forEach(row => {
            row.cells?.forEach((cell, cellIndex) => {
              if (cell.type === 'blank') {
                stats[key].total++

                if (!isTableCellCorrect(submission, question, row, cellIndex)) {
                  stats[key].wrong++
                }
              }
            })
          })

          return
        }

        stats[key].total++

        if (!isNormalCorrect(submission, question)) {
          stats[key].wrong++
        }
      })
    })

    return Object.values(stats)
      .filter(item => item.total > 0)
      .map(item => ({
        ...item,
        wrongRate: Math.round((item.wrong / item.total) * 100)
      }))
      .sort((a, b) => b.wrongRate - a.wrongRate)
      .slice(0, 5)
  }

  const getAtRiskListeningStudents = () => {
    return students
      .map(student => {
        const studentSubs = listeningSubmissions
          .filter(sub => sub.uid === student.id && sub.result?.band)
          .sort(
            (a, b) =>
              new Date(b.submittedAt || 0) - new Date(a.submittedAt || 0)
          )

        const latest = studentSubs[0]

        if (!latest) return null

        return {
          student,
          latestBand: Number(latest.result.band),
          submissions: studentSubs.length
        }
      })
      .filter(item => item && item.latestBand < 6)
      .sort((a, b) => a.latestBand - b.latestBand)
      .slice(0, 5)
  }

  const getListeningTypeAnalytics = () => {
    const stats = {
      mcq: { correct: 0, total: 0 },
      fitb: { correct: 0, total: 0 },
      tfng: { correct: 0, total: 0 },
      table: { correct: 0, total: 0 },
      note: { correct: 0, total: 0 }
    }

    listeningSubmissions.forEach(submission => {
      const listening = listenings.find(item => item.id === submission.listeningId)
      if (!listening) return

      listening.questions?.forEach(question => {
        if (question.type === 'table' || question.type === 'summary' || question.type === 'note') {
          question.rows?.forEach(row => {
            row.cells?.forEach((cell, cellIndex) => {
              if (cell.type === 'blank') {
                stats.table.total++

                if (isTableCellCorrect(submission, question, row, cellIndex)) {
                  stats.table.correct++
                }
              }
            })
          })

          return
        }

        if (!stats[question.type]) return

        stats[question.type].total++

        if (isNormalCorrect(submission, question)) {
          stats[question.type].correct++
        }
      })
    })

    return Object.entries(stats).map(([key, value]) => ({
      key,
      correct: value.correct,
      total: value.total,
      percentage: value.total
        ? Math.round((value.correct / value.total) * 100)
        : null
    }))
  }

  const getListeningTypeLabel = type => {
    if (type === 'mcq') return 'MCQ'
    if (type === 'fitb') return 'Fill Blank'
    if (type === 'tfng') return 'T/F/NG'
    if (type === 'table') return 'Form/Table'
    if (type === 'note') return 'Note Completion'
    return type
  }

  const handlePrint = student => {
    const studentScores = scores[student.id] || []
    const printWindow = window.open('', '_blank')

    printWindow.document.write(`
      <html>
        <head>
          <title>${student.name} - IELTS Scores</title>
          <style>
            body { font-family: sans-serif; padding: 40px; color: #111; }
            h1 { font-size: 24px; margin-bottom: 4px; }
            p { color: #666; font-size: 14px; margin-bottom: 30px; }
            table { width: 100%; border-collapse: collapse; }
            th { background: #7c3aed; color: white; padding: 10px 14px; text-align: left; font-size: 13px; }
            td { padding: 10px 14px; font-size: 13px; border-bottom: 1px solid #eee; }
            .overall { font-weight: bold; color: #7c3aed; }
            img { height: 50px; margin-bottom: 20px; }
          </style>
        </head>
        <body>
          <img src="${window.location.origin}/1.png" />
          <h1>${student.name}</h1>
          <p>${student.email} — IELTS Score Report</p>
          <table>
            <thead>
              <tr>
                <th>Date</th>
                <th>Listening</th>
                <th>Reading</th>
                <th>Writing</th>
                <th>Speaking</th>
                <th>Overall</th>
              </tr>
            </thead>
            <tbody>
              ${studentScores
                .map(
                  s => `
                <tr>
                  <td>${s.date}</td>
                  <td>${s.listening}</td>
                  <td>${s.reading}</td>
                  <td>${s.writing}</td>
                  <td>${s.speaking}</td>
                  <td class="overall">${s.overall}</td>
                </tr>
              `
                )
                .join('')}
            </tbody>
          </table>
        </body>
      </html>
    `)

    printWindow.document.close()
    printWindow.print()
  }

  const handleChangePassword = async () => {
    if (newPassword.length < 6) {
      setPasswordMsg('Password must be at least 6 characters')
      return
    }

    try {
      await updatePassword(auth.currentUser, newPassword)
      setPasswordMsg('Password changed successfully!')
      setNewPassword('')
    } catch (err) {
      setPasswordMsg(
        'Error: Please log out and log back in first, then try again.'
      )
    }
  }

  const openWritingReview = ({ student, writing, submission }) => {
    setSelectedMockWritingReview(null)
    setSelectedWritingReview({ student, writing, submission })

    setWritingReviewForm({
      task1Band: submission.review?.task1Band || '',
      task2Band: submission.review?.task2Band || '',
      task1TA: submission.review?.rubric?.task1?.taskAchievement || '',
      task1CC: submission.review?.rubric?.task1?.coherenceCohesion || '',
      task1LR: submission.review?.rubric?.task1?.lexicalResource || '',
      task1GRA: submission.review?.rubric?.task1?.grammarRangeAccuracy || '',
      task2TR: submission.review?.rubric?.task2?.taskResponse || '',
      task2CC: submission.review?.rubric?.task2?.coherenceCohesion || '',
      task2LR: submission.review?.rubric?.task2?.lexicalResource || '',
      task2GRA: submission.review?.rubric?.task2?.grammarRangeAccuracy || '',
      task1Feedback: submission.review?.task1Feedback || '',
      task2Feedback: submission.review?.task2Feedback || '',
      overall: submission.review?.overall || '',
      generalFeedback: submission.review?.generalFeedback || ''
    })
  }

  const openMockWritingReview = ({ student, mock, submission }) => {
    const review = getMockWritingReview(submission) || {}

    setSelectedWritingReview(null)
    setSelectedMockWritingReview({ student, mock, submission })

    setWritingReviewForm({
      task1Band: review.task1Band || submission.result?.writing?.task1Band || '',
      task2Band: review.task2Band || submission.result?.writing?.task2Band || '',
      task1TA: review.rubric?.task1?.taskAchievement || '',
      task1CC: review.rubric?.task1?.coherenceCohesion || '',
      task1LR: review.rubric?.task1?.lexicalResource || '',
      task1GRA: review.rubric?.task1?.grammarRangeAccuracy || '',
      task2TR: review.rubric?.task2?.taskResponse || '',
      task2CC: review.rubric?.task2?.coherenceCohesion || '',
      task2LR: review.rubric?.task2?.lexicalResource || '',
      task2GRA: review.rubric?.task2?.grammarRangeAccuracy || '',
      task1Feedback: review.task1Feedback || '',
      task2Feedback: review.task2Feedback || '',
      overall: review.overall || submission.result?.writing?.band || '',
      generalFeedback: review.generalFeedback || ''
    })
  }

  const roundToHalf = value => {
    if (!value && value !== 0) return ''

    return (Math.round(Number(value) * 2) / 2).toFixed(1)
  }

  const averageBand = values => {
    const numbers = values
      .map(value => Number(value))
      .filter(value => !Number.isNaN(value) && value > 0)

    if (numbers.length === 0) return ''

    const avg = numbers.reduce((sum, value) => sum + value, 0) / numbers.length

    return roundToHalf(avg)
  }

  const suggestedTask1Band = averageBand([
    writingReviewForm.task1TA,
    writingReviewForm.task1CC,
    writingReviewForm.task1LR,
    writingReviewForm.task1GRA
  ])

  const suggestedTask2Band = averageBand([
    writingReviewForm.task2TR,
    writingReviewForm.task2CC,
    writingReviewForm.task2LR,
    writingReviewForm.task2GRA
  ])

  const suggestedOverallBand = averageBand([
    writingReviewForm.task1Band || suggestedTask1Band,
    writingReviewForm.task2Band || suggestedTask2Band
  ])

  const useSuggestedBands = () => {
    setWritingReviewForm(prev => ({
      ...prev,
      task1Band: prev.task1Band || suggestedTask1Band,
      task2Band: prev.task2Band || suggestedTask2Band,
      overall: suggestedOverallBand || prev.overall
    }))
  }

  const resetWritingReviewForm = () => {
    setWritingReviewForm({
      task1Band: '',
      task2Band: '',
      task1TA: '',
      task1CC: '',
      task1LR: '',
      task1GRA: '',
      task2TR: '',
      task2CC: '',
      task2LR: '',
      task2GRA: '',
      task1Feedback: '',
      task2Feedback: '',
      overall: '',
      generalFeedback: ''
    })
  }

  const buildWritingReviewPayload = () => ({
    task1Band: writingReviewForm.task1Band,
    task2Band: writingReviewForm.task2Band,
    rubric: {
      task1: {
        taskAchievement: writingReviewForm.task1TA,
        coherenceCohesion: writingReviewForm.task1CC,
        lexicalResource: writingReviewForm.task1LR,
        grammarRangeAccuracy: writingReviewForm.task1GRA
      },
      task2: {
        taskResponse: writingReviewForm.task2TR,
        coherenceCohesion: writingReviewForm.task2CC,
        lexicalResource: writingReviewForm.task2LR,
        grammarRangeAccuracy: writingReviewForm.task2GRA
      }
    },
    task1Feedback: writingReviewForm.task1Feedback,
    task2Feedback: writingReviewForm.task2Feedback,
    overall: writingReviewForm.overall,
    generalFeedback: writingReviewForm.generalFeedback
  })

  const saveWritingReview = async () => {
    if (!selectedWritingReview) return

    if (!writingReviewForm.overall) {
      alert('Please enter overall writing band.')
      return
    }

    await updateDoc(
      doc(db, 'writingSubmissions', selectedWritingReview.submission.id),
      {
        reviewed: true,
        reviewedAt: new Date().toISOString(),
        reviewedBy: user.uid,
        review: buildWritingReviewPayload()
      }
    )

    setSelectedWritingReview(null)
    resetWritingReviewForm()
  }

  const saveMockWritingReview = async () => {
    if (!selectedMockWritingReview) return

    if (!writingReviewForm.overall) {
      alert('Please enter overall writing band.')
      return
    }

    const submission = selectedMockWritingReview.submission
    const result = submission.result || {}
    const review = buildWritingReviewPayload()

    const listeningBand = Number(result.listening?.band)
    const readingBand = Number(result.reading?.band)
    const writingBand = Number(writingReviewForm.overall)

    const overallInputs = [listeningBand, readingBand, writingBand].filter(
      value => !Number.isNaN(value) && value > 0
    )

    const finalOverall =
      overallInputs.length > 0
        ? roundToHalf(
            overallInputs.reduce((sum, value) => sum + value, 0) /
              overallInputs.length
          )
        : writingReviewForm.overall

    await updateDoc(
      doc(db, 'mockSubmissions', submission.id),
      {
        reviewedAt: new Date().toISOString(),
        reviewedBy: user.uid,
        writingReview: {
          status: 'reviewed',
          ...review
        },
        result: {
          ...result,
          writing: {
            ...(result.writing || {}),
            status: 'reviewed',
            band: writingReviewForm.overall,
            task1Band: writingReviewForm.task1Band,
            task2Band: writingReviewForm.task2Band,
            review
          },
          finalOverall,
          overallEstimate: finalOverall,
          overall: finalOverall
        }
      }
    )

    setSelectedMockWritingReview(null)
    resetWritingReviewForm()
  }

  const renderReadingHomeworkCard = (reading, archived = false) => (
    <div
      key={reading.id}
      className={`border rounded-xl p-4 flex items-center justify-between gap-4 ${
        archived
          ? 'border-gray-100 bg-gray-50 opacity-80'
          : 'border-gray-100 bg-gray-50'
      }`}
    >
      <div>
        <p className="text-sm font-medium text-gray-800">{reading.title}</p>

        <p className="text-xs text-gray-400 mt-0.5">
          Assigned to {reading.assignTo?.length || 0} students · Completed by{' '}
          {getCompletedCount(reading.id)} students · {reading.timeLimit} min
        </p>

        {archived && (
          <p className="text-xs text-amber-600 mt-1 font-medium">
            Archived — hidden from students
          </p>
        )}
      </div>

      <div className="flex gap-2 flex-wrap justify-end">
        {!archived && (
          <>
            <button
              onClick={() => navigate(`/edit-reading/${reading.id}`)}
              className="text-xs bg-blue-50 text-blue-600 px-3 py-2 rounded-xl hover:bg-blue-100"
            >
              Edit
            </button>

            <button
              onClick={() => duplicateReadingHomework(reading)}
              className="text-xs bg-gray-100 text-gray-600 px-3 py-2 rounded-xl hover:bg-gray-200"
            >
              Duplicate
            </button>

            <button
              onClick={() => openAssignmentManager(reading, 'reading')}
              className="text-xs bg-purple-600 text-white px-3 py-2 rounded-xl hover:bg-purple-700"
            >
              Manage
            </button>
          </>
        )}

        {archived ? (
          <button
            onClick={() => restoreReadingHomework(reading)}
            className="text-xs bg-green-50 text-green-600 px-3 py-2 rounded-xl hover:bg-green-100"
          >
            Restore
          </button>
        ) : (
          <button
            onClick={() => archiveReadingHomework(reading)}
            className="text-xs bg-amber-50 text-amber-600 px-3 py-2 rounded-xl hover:bg-amber-100"
          >
            Archive
          </button>
        )}

        <button
          onClick={() => deleteReadingHomework(reading)}
          className="text-xs bg-red-50 text-red-600 px-3 py-2 rounded-xl hover:bg-red-100"
        >
          Delete
        </button>
      </div>
    </div>
  )

  const renderWritingHomeworkCard = (writing, archived = false) => {
    const submitted = getWritingSubmittedCount(writing.id)
    const reviewed = getWritingReviewedCount(writing.id)

    return (
      <div
        key={writing.id}
        className={`border rounded-xl p-4 flex items-center justify-between gap-4 ${
          archived
            ? 'border-gray-100 bg-gray-50 opacity-80'
            : 'border-gray-100 bg-gray-50'
        }`}
      >
        <div>
          <p className="text-sm font-medium text-gray-800">{writing.title}</p>

          <p className="text-xs text-gray-400 mt-0.5">
            Assigned to {writing.assignTo?.length || 0} students · Submitted by{' '}
            {submitted} students · Reviewed {reviewed}/{submitted} ·{' '}
            {writing.timeLimit || 60} min
          </p>

          {submitted > reviewed && (
            <p className="text-xs text-amber-600 mt-1 font-medium">
              {submitted - reviewed} pending teacher review
            </p>
          )}

          {archived && (
            <p className="text-xs text-amber-600 mt-1 font-medium">
              Archived — hidden from students
            </p>
          )}
        </div>

        <div className="flex gap-2 flex-wrap justify-end">
          {!archived && (
            <>
              <button
                onClick={() => navigate(`/edit-writing/${writing.id}`)}
                className="text-xs bg-blue-50 text-blue-600 px-3 py-2 rounded-xl hover:bg-blue-100"
              >
                Edit
              </button>

              <button
                onClick={() => duplicateWritingHomework(writing)}
                className="text-xs bg-gray-100 text-gray-600 px-3 py-2 rounded-xl hover:bg-gray-200"
              >
                Duplicate
              </button>

              <button
                onClick={() => openAssignmentManager(writing, 'writing')}
                className="text-xs bg-purple-600 text-white px-3 py-2 rounded-xl hover:bg-purple-700"
              >
                Manage
              </button>
            </>
          )}

          {archived ? (
            <button
              onClick={() => restoreWritingHomework(writing)}
              className="text-xs bg-green-50 text-green-600 px-3 py-2 rounded-xl hover:bg-green-100"
            >
              Restore
            </button>
          ) : (
            <button
              onClick={() => archiveWritingHomework(writing)}
              className="text-xs bg-amber-50 text-amber-600 px-3 py-2 rounded-xl hover:bg-amber-100"
            >
              Archive
            </button>
          )}

          <button
            onClick={() => deleteWritingHomework(writing)}
            className="text-xs bg-red-50 text-red-600 px-3 py-2 rounded-xl hover:bg-red-100"
          >
            Delete
          </button>
        </div>
      </div>
    )
  }

  const renderListeningHomeworkCard = (listening, archived = false) => (
    <div
      key={listening.id}
      className={`border rounded-xl p-4 flex items-center justify-between gap-4 ${
        archived
          ? 'border-gray-100 bg-gray-50 opacity-80'
          : 'border-gray-100 bg-gray-50'
      }`}
    >
      <div>
        <p className="text-sm font-medium text-gray-800">{listening.title}</p>

        <p className="text-xs text-gray-400 mt-0.5">
          Assigned to {listening.assignTo?.length || 0} students · Completed by{' '}
          {getListeningCompletedCount(listening.id)} students · {listening.timeLimit || 30} min
        </p>

        {archived && (
          <p className="text-xs text-amber-600 mt-1 font-medium">
            Archived — hidden from students
          </p>
        )}
      </div>

      <div className="flex gap-2 flex-wrap justify-end">
        {!archived && (
          <>
            <button
              onClick={() => navigate(`/edit-listening/${listening.id}`)}
              className="text-xs bg-blue-50 text-blue-600 px-3 py-2 rounded-xl hover:bg-blue-100"
            >
              Edit
            </button>

            <button
              onClick={() => duplicateListeningHomework(listening)}
              className="text-xs bg-gray-100 text-gray-600 px-3 py-2 rounded-xl hover:bg-gray-200"
            >
              Duplicate
            </button>

            <button
              onClick={() => openAssignmentManager(listening, 'listening')}
              className="text-xs bg-purple-600 text-white px-3 py-2 rounded-xl hover:bg-purple-700"
            >
              Manage
            </button>
          </>
        )}

        {archived ? (
          <button
            onClick={() => restoreListeningHomework(listening)}
            className="text-xs bg-green-50 text-green-600 px-3 py-2 rounded-xl hover:bg-green-100"
          >
            Restore
          </button>
        ) : (
          <button
            onClick={() => archiveListeningHomework(listening)}
            className="text-xs bg-amber-50 text-amber-600 px-3 py-2 rounded-xl hover:bg-amber-100"
          >
            Archive
          </button>
        )}

        <button
          onClick={() => deleteListeningHomework(listening)}
          className="text-xs bg-red-50 text-red-600 px-3 py-2 rounded-xl hover:bg-red-100"
        >
          Delete
        </button>
      </div>
    </div>
  )


  const averageReadingEstimatedBand = getAverageReadingEstimatedBand()
  const readingCompletionStats = getReadingCompletionStats()
  const mostMissedReadingQuestions = getMostMissedReadingQuestions()
  const atRiskReadingStudents = getAtRiskReadingStudents()
  const readingTypeAnalytics = getReadingTypeAnalytics()

  const averageListeningBand = getAverageListeningBand()
  const listeningCompletionStats = getListeningCompletionStats()
  const mostMissedListeningQuestions = getMostMissedListeningQuestions()
  const atRiskListeningStudents = getAtRiskListeningStudents()
  const listeningTypeAnalytics = getListeningTypeAnalytics()

  const teacherTabs = [
    ['overview', 'Overview'],
    ['students', 'Students'],
    ['library', 'Homework Library'],
    ['analytics', 'Analytics'],
    ['reviews', 'Writing Reviews']
  ]

  return (
    <div className="min-h-screen bg-[#faf9f6]">
      <nav className="flex justify-between items-center px-8 py-4 bg-white border-b border-gray-100">
        <img src="/1.png" alt="Maxima" className="h-10 object-contain" />

        <div className="flex items-center gap-4">
          <span className="text-sm text-gray-400">{user?.email}</span>

          <button
            onClick={() => setShowPasswordModal(true)}
            className="text-sm text-gray-400 hover:text-gray-600"
          >
            Change Password
          </button>

          <button
            onClick={() => {
              signOut(auth)
              navigate('/')
            }}
            className="text-sm text-gray-400 hover:text-gray-600"
          >
            Logout
          </button>
        </div>
      </nav>

      <div className="max-w-6xl mx-auto px-6 py-10">
        <h1 className="text-2xl font-bold text-gray-900 mb-1">
          Teacher Dashboard
        </h1>

        <p className="text-gray-400 text-sm mb-6">
          Manage students, scores and reusable homework
        </p>

        <div className="flex items-center gap-4 mb-8">
          <button
            onClick={() => navigate('/create-reading')}
            className="bg-purple-600 text-white px-4 py-2 rounded-xl text-sm font-medium hover:bg-purple-700"
          >
            📖 Create Reading Homework
          </button>

          <button
            onClick={() => navigate('/create-writing')}
            className="bg-purple-600 text-white px-4 py-2 rounded-xl text-sm font-medium hover:bg-purple-700"
          >
            ✍️ Create Writing Homework
          </button>

          <button
            onClick={() => navigate('/create-listening')}
            className="bg-purple-600 text-white px-4 py-2 rounded-xl text-sm font-medium hover:bg-purple-700"
          >
            🎧 Create Listening Homework
          </button>

          <button
            onClick={() => navigate('/create-mock')}
            className="bg-green-600 text-white px-4 py-2 rounded-xl text-sm font-medium hover:bg-green-700"
          >
            🧪 Create Mock Test
          </button>
        </div>

        <div className="bg-white border border-gray-100 rounded-2xl p-2 mb-8 flex gap-2 overflow-x-auto">
          {teacherTabs.map(([key, label]) => (
            <button
              key={key}
              onClick={() => setActiveTab(key)}
              className={`whitespace-nowrap px-4 py-2.5 rounded-xl text-sm font-medium transition-all ${
                activeTab === key
                  ? 'bg-purple-600 text-white'
                  : 'text-gray-500 hover:bg-gray-100'
              }`}
            >
              {label}
            </button>
          ))}
        </div>

{activeTab === 'overview' && (
          <>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-8">
          <div className="bg-gray-900 text-white rounded-2xl p-5">
            <p className="text-xs text-gray-400 mb-1">
              Pending Essays
            </p>

            <p className="text-3xl font-bold">
              {totalPendingWritingReviews}
            </p>

            <p className="text-xs text-gray-400 mt-2">
              Need teacher grading
            </p>
          </div>

          <div className="bg-white border border-gray-100 rounded-2xl p-5">
            <p className="text-xs text-gray-400 mb-1">
              Reviewed Writing
            </p>

            <p className="text-3xl font-bold text-green-600">
              {reviewedWritingCount}
            </p>

            <p className="text-xs text-gray-400 mt-2">
              Total reviewed submissions
            </p>
          </div>

          <div className="bg-white border border-gray-100 rounded-2xl p-5">
            <p className="text-xs text-gray-400 mb-1">
              Total Writing Submissions
            </p>

            <p className="text-3xl font-bold text-purple-600">
              {submittedWritingCount}
            </p>

            <p className="text-xs text-gray-400 mt-2">
              Submitted Task 1 + Task 2 sets
            </p>
          </div>
        </div>

        

          </>
        )}

        {activeTab === 'analytics' && (
          <>
        <div className="bg-white border border-gray-100 rounded-2xl p-6 mb-8">
          <div className="flex items-start justify-between gap-4 mb-5">
            <div>
              <h2 className="font-semibold text-gray-800">
                📖 Reading Analytics
              </h2>

              <p className="text-xs text-gray-400 mt-1">
                Class accuracy, completion rate, difficult questions and at-risk students.
              </p>
            </div>

            <span className="text-xs bg-blue-50 text-blue-600 px-3 py-1.5 rounded-full">
              {submissions.length} submissions
            </span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
            <div className="bg-gray-900 text-white rounded-2xl p-5">
              <p className="text-xs text-gray-400 mb-1">
                Average Reading Estimated Band
              </p>

              <p className="text-3xl font-bold">
                {averageReadingEstimatedBand || '--'}
              </p>

              <p className="text-xs text-gray-400 mt-2">
                Based on submitted reading homework
              </p>
            </div>

            <div className="bg-blue-50 rounded-2xl p-5">
              <p className="text-xs text-gray-500 mb-1">
                Completion Rate
              </p>

              <p className="text-3xl font-bold text-blue-600">
                {readingCompletionStats.rate}%
              </p>

              <p className="text-xs text-gray-500 mt-2">
                {readingCompletionStats.completed}/{readingCompletionStats.assigned} assignments completed
              </p>
            </div>

            <div className="bg-red-50 rounded-2xl p-5">
              <p className="text-xs text-gray-500 mb-1">
                Most Missed Question
              </p>

              <p className="text-xl font-bold text-red-600 truncate">
                {mostMissedReadingQuestions[0]?.label || '--'}
              </p>

              <p className="text-xs text-gray-500 mt-2">
                {mostMissedReadingQuestions[0]
                  ? `${mostMissedReadingQuestions[0].wrongRate}% wrong`
                  : 'No question data yet'}
              </p>
            </div>

            <div className="bg-amber-50 rounded-2xl p-5">
              <p className="text-xs text-gray-500 mb-1">
                At-Risk Students
              </p>

              <p className="text-3xl font-bold text-amber-600">
                {atRiskReadingStudents.length}
              </p>

              <p className="text-xs text-gray-500 mt-2">
                Latest reading estimate below 6.0
              </p>
            </div>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
            <div className="lg:col-span-1 bg-gray-50 rounded-2xl p-5">
              <h3 className="text-sm font-semibold text-gray-700 mb-3">
                Accuracy by Question Type
              </h3>

              <div className="flex flex-col gap-3">
                {readingTypeAnalytics.map(item => (
                  <div key={item.key}>
                    <div className="flex justify-between mb-1">
                      <p className="text-xs text-gray-500">
                        {getReadingTypeLabel(item.key)}
                      </p>

                      <p className={`text-xs font-semibold ${getAnalyticsColor(item.percentage)}`}>
                        {item.percentage === null ? '--' : `${item.percentage}%`}
                      </p>
                    </div>

                    <div className="w-full bg-white rounded-full h-2 overflow-hidden">
                      <div
                        className="bg-blue-600 h-2 rounded-full"
                        style={{ width: `${item.percentage || 0}%` }}
                      />
                    </div>

                    <p className="text-[10px] text-gray-400 mt-1">
                      {item.correct}/{item.total} correct
                    </p>
                  </div>
                ))}
              </div>
            </div>

            <div className="lg:col-span-1 bg-gray-50 rounded-2xl p-5">
              <h3 className="text-sm font-semibold text-gray-700 mb-3">
                Most Missed Questions
              </h3>

              {mostMissedReadingQuestions.length === 0 ? (
                <p className="text-sm text-gray-400">
                  No reading submissions yet.
                </p>
              ) : (
                <div className="flex flex-col gap-2">
                  {mostMissedReadingQuestions.map(item => (
                    <div
                      key={item.label}
                      className="bg-white rounded-xl p-3 flex items-center justify-between gap-3"
                    >
                      <div className="min-w-0">
                        <p className="text-xs font-medium text-gray-700 truncate">
                          {item.label}
                        </p>

                        <p className="text-[10px] text-gray-400">
                          {item.wrong}/{item.total} wrong
                        </p>
                      </div>

                      <span className="text-xs bg-red-50 text-red-600 px-2 py-1 rounded-full font-semibold">
                        {item.wrongRate}%
                      </span>
                    </div>
                  ))}
                </div>
              )}
            </div>

            <div className="lg:col-span-1 bg-gray-50 rounded-2xl p-5">
              <h3 className="text-sm font-semibold text-gray-700 mb-3">
                At-Risk Students
              </h3>

              {atRiskReadingStudents.length === 0 ? (
                <p className="text-sm text-gray-400">
                  No at-risk reading students yet.
                </p>
              ) : (
                <div className="flex flex-col gap-2">
                  {atRiskReadingStudents.map(item => (
                    <div
                      key={item.student.id}
                      className="bg-white rounded-xl p-3 flex items-center justify-between gap-3"
                    >
                      <div>
                        <p className="text-xs font-medium text-gray-700">
                          {item.student.name}
                        </p>

                        <p className="text-[10px] text-gray-400">
                          {item.submissions} reading submission(s)
                        </p>
                      </div>

                      <span className="text-xs bg-amber-50 text-amber-600 px-2 py-1 rounded-full font-semibold">
                        Est. {item.latestBand.toFixed(1)}
                      </span>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        </div>


        <div className="bg-white border border-gray-100 rounded-2xl p-6 mb-8">
          <div className="flex items-start justify-between gap-4 mb-5">
            <div>
              <h2 className="font-semibold text-gray-800">
                🎧 Listening Analytics
              </h2>

              <p className="text-xs text-gray-400 mt-1">
                Class performance, completion rate, difficult questions and at-risk students.
              </p>
            </div>

            <span className="text-xs bg-purple-50 text-purple-600 px-3 py-1.5 rounded-full">
              {listeningSubmissions.length} submissions
            </span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
            <div className="bg-gray-900 text-white rounded-2xl p-5">
              <p className="text-xs text-gray-400 mb-1">
                Average Listening Band
              </p>

              <p className="text-3xl font-bold">
                {averageListeningBand || '--'}
              </p>

              <p className="text-xs text-gray-400 mt-2">
                Based on submitted listening homework
              </p>
            </div>

            <div className="bg-purple-50 rounded-2xl p-5">
              <p className="text-xs text-gray-500 mb-1">
                Completion Rate
              </p>

              <p className="text-3xl font-bold text-purple-600">
                {listeningCompletionStats.rate}%
              </p>

              <p className="text-xs text-gray-500 mt-2">
                {listeningCompletionStats.completed}/{listeningCompletionStats.assigned} assignments completed
              </p>
            </div>

            <div className="bg-red-50 rounded-2xl p-5">
              <p className="text-xs text-gray-500 mb-1">
                Most Missed Question
              </p>

              <p className="text-xl font-bold text-red-600 truncate">
                {mostMissedListeningQuestions[0]?.label || '--'}
              </p>

              <p className="text-xs text-gray-500 mt-2">
                {mostMissedListeningQuestions[0]
                  ? `${mostMissedListeningQuestions[0].wrongRate}% wrong`
                  : 'No question data yet'}
              </p>
            </div>

            <div className="bg-amber-50 rounded-2xl p-5">
              <p className="text-xs text-gray-500 mb-1">
                At-Risk Students
              </p>

              <p className="text-3xl font-bold text-amber-600">
                {atRiskListeningStudents.length}
              </p>

              <p className="text-xs text-gray-500 mt-2">
                Latest listening band below 6.0
              </p>
            </div>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
            <div className="lg:col-span-1 bg-gray-50 rounded-2xl p-5">
              <h3 className="text-sm font-semibold text-gray-700 mb-3">
                Accuracy by Question Type
              </h3>

              <div className="flex flex-col gap-3">
                {listeningTypeAnalytics.map(item => (
                  <div key={item.key}>
                    <div className="flex justify-between mb-1">
                      <p className="text-xs text-gray-500">
                        {getListeningTypeLabel(item.key)}
                      </p>

                      <p className={`text-xs font-semibold ${getAnalyticsColor(item.percentage)}`}>
                        {item.percentage === null ? '--' : `${item.percentage}%`}
                      </p>
                    </div>

                    <div className="w-full bg-white rounded-full h-2 overflow-hidden">
                      <div
                        className="bg-purple-600 h-2 rounded-full"
                        style={{ width: `${item.percentage || 0}%` }}
                      />
                    </div>

                    <p className="text-[10px] text-gray-400 mt-1">
                      {item.correct}/{item.total} correct
                    </p>
                  </div>
                ))}
              </div>
            </div>

            <div className="lg:col-span-1 bg-gray-50 rounded-2xl p-5">
              <h3 className="text-sm font-semibold text-gray-700 mb-3">
                Most Missed Questions
              </h3>

              {mostMissedListeningQuestions.length === 0 ? (
                <p className="text-sm text-gray-400">
                  No listening submissions yet.
                </p>
              ) : (
                <div className="flex flex-col gap-2">
                  {mostMissedListeningQuestions.map(item => (
                    <div
                      key={item.label}
                      className="bg-white rounded-xl p-3 flex items-center justify-between gap-3"
                    >
                      <div className="min-w-0">
                        <p className="text-xs font-medium text-gray-700 truncate">
                          {item.label}
                        </p>

                        <p className="text-[10px] text-gray-400">
                          {item.wrong}/{item.total} wrong
                        </p>
                      </div>

                      <span className="text-xs bg-red-50 text-red-600 px-2 py-1 rounded-full font-semibold">
                        {item.wrongRate}%
                      </span>
                    </div>
                  ))}
                </div>
              )}
            </div>

            <div className="lg:col-span-1 bg-gray-50 rounded-2xl p-5">
              <h3 className="text-sm font-semibold text-gray-700 mb-3">
                At-Risk Students
              </h3>

              {atRiskListeningStudents.length === 0 ? (
                <p className="text-sm text-gray-400">
                  No at-risk listening students yet.
                </p>
              ) : (
                <div className="flex flex-col gap-2">
                  {atRiskListeningStudents.map(item => (
                    <div
                      key={item.student.id}
                      className="bg-white rounded-xl p-3 flex items-center justify-between gap-3"
                    >
                      <div>
                        <p className="text-xs font-medium text-gray-700">
                          {item.student.name}
                        </p>

                        <p className="text-[10px] text-gray-400">
                          {item.submissions} listening submission(s)
                        </p>
                      </div>

                      <span className="text-xs bg-amber-50 text-amber-600 px-2 py-1 rounded-full font-semibold">
                        Band {item.latestBand.toFixed(1)}
                      </span>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        </div>


          </>
        )}

        {activeTab === 'reviews' && (
          <>
<div className="bg-white border border-gray-100 rounded-2xl p-6 mb-8">
          <div className="flex items-center justify-between gap-4 mb-4">
            <div>
              <h2 className="font-semibold text-gray-800">
                Pending Writing Reviews
              </h2>

              <p className="text-xs text-gray-400 mt-1">
                Essays submitted by students but not graded yet. Click Grade Now to open the review screen directly.
              </p>
            </div>

            <span className={`text-xs px-3 py-1.5 rounded-full ${
              pendingWritingReviews.length > 0
                ? 'bg-amber-50 text-amber-600'
                : 'bg-green-50 text-green-600'
            }`}>
              {pendingWritingReviews.length > 0
                ? `${pendingWritingReviews.length} pending`
                : 'All caught up'}
            </span>
          </div>

          {pendingWritingReviews.length === 0 ? (
            <div className="bg-green-50 text-green-700 rounded-xl p-4 text-sm">
              ✅ No pending writing reviews right now.
            </div>
          ) : (
            <div className="flex flex-col gap-3">
              {pendingWritingReviews.slice(0, 6).map(item => (
                <div
                  key={item.submission.id}
                  className="border border-amber-100 bg-amber-50/40 rounded-xl p-4 flex items-center justify-between gap-4"
                >
                  <div>
                    <p className="text-sm font-medium text-gray-800">
                      {item.student.name}
                    </p>

                    <p className="text-xs text-gray-500 mt-0.5">
                      {item.writing.title} · Submitted {formatDateShort(item.submission.submittedAt)}
                    </p>

                    <p className="text-xs text-gray-400 mt-1">
                      Task 1: {item.submission.task1WordCount || 0} words · Task 2: {item.submission.task2WordCount || 0} words
                    </p>
                  </div>

                  <button
                    onClick={() => openWritingReview(item)}
                    className="text-xs bg-purple-600 text-white px-4 py-2 rounded-xl hover:bg-purple-700"
                  >
                    Grade Now
                  </button>
                </div>
              ))}

              {pendingWritingReviews.length > 6 && (
                <p className="text-xs text-gray-400 text-center pt-2">
                  Showing latest 6 pending reviews. Use the Pending Review filter in Writing Homework Library for the full list.
                </p>
              )}
            </div>
          )}
        </div>

        <div className="bg-white border border-gray-100 rounded-2xl p-6 mb-8">
          <div className="flex items-center justify-between gap-4 mb-4">
            <div>
              <h2 className="font-semibold text-gray-800">
                Pending Mock Writing Reviews
              </h2>

              <p className="text-xs text-gray-400 mt-1">
                Writing sections submitted inside full mock tests.
              </p>
            </div>

            <span className={`text-xs px-3 py-1.5 rounded-full ${
              pendingMockWritingReviews.length > 0
                ? 'bg-amber-50 text-amber-600'
                : 'bg-green-50 text-green-600'
            }`}>
              {pendingMockWritingReviews.length > 0
                ? `${pendingMockWritingReviews.length} pending`
                : 'All caught up'}
            </span>
          </div>

          {pendingMockWritingReviews.length === 0 ? (
            <div className="bg-green-50 text-green-700 rounded-xl p-4 text-sm">
              ✅ No pending mock writing reviews right now.
            </div>
          ) : (
            <div className="flex flex-col gap-3">
              {pendingMockWritingReviews.slice(0, 8).map(item => (
                <div
                  key={item.submission.id}
                  className="border border-purple-100 bg-purple-50/40 rounded-xl p-4 flex items-center justify-between gap-4"
                >
                  <div>
                    <p className="text-sm font-medium text-gray-800">
                      {item.student.name}
                    </p>

                    <p className="text-xs text-gray-500 mt-0.5">
                      {item.mock?.title || item.submission.mockTitle || 'Mock Test'} · Submitted {formatDateShort(item.submission.submittedAt)}
                    </p>

                    <p className="text-xs text-gray-400 mt-1">
                      Task 1: {getMockTask1WordCount(item.submission) || 0} words · Task 2: {getMockTask2WordCount(item.submission) || 0} words
                    </p>
                  </div>

                  <button
                    onClick={() => openMockWritingReview(item)}
                    className="text-xs bg-purple-600 text-white px-4 py-2 rounded-xl hover:bg-purple-700"
                  >
                    Grade Mock
                  </button>
                </div>
              ))}
            </div>
          )}
        </div>


          </>
        )}

        {activeTab === 'library' && (
          <>
        <div className="bg-white border border-gray-100 rounded-2xl p-6 mb-8">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h2 className="font-semibold text-gray-800">
                Reading Homework Library
              </h2>

              <p className="text-xs text-gray-400 mt-1">
                Reuse, duplicate, assign, unassign, archive or delete reading homework.
              </p>
            </div>

            <div className="flex items-center gap-2 flex-wrap justify-end">
              {[
                ['active', `Active (${activeReadings.length})`],
                ['archived', `Archived (${archivedReadings.length})`],
                ['all', `All (${readings.length})`]
              ].map(([key, label]) => (
                <button
                  key={key}
                  onClick={() => setReadingLibraryFilter(key)}
                  className={`text-xs px-3 py-1.5 rounded-full ${
                    readingLibraryFilter === key
                      ? 'bg-purple-600 text-white'
                      : 'bg-gray-100 text-gray-500 hover:bg-gray-200'
                  }`}
                >
                  {label}
                </button>
              ))}
            </div>
          </div>

          {filteredReadings.length === 0 ? (
            <p className="text-sm text-gray-400 bg-gray-50 rounded-xl p-4">
              No reading homework found for this filter.
            </p>
          ) : (
            <div className="flex flex-col gap-3">
              {filteredReadings.map(reading =>
                renderReadingHomeworkCard(reading, reading.archived)
              )}
            </div>
          )}
        </div>


        <div className="bg-white border border-gray-100 rounded-2xl p-6 mb-8">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h2 className="font-semibold text-gray-800">
                Listening Homework Library
              </h2>

              <p className="text-xs text-gray-400 mt-1">
                Reuse, duplicate, assign, unassign, archive or delete listening homework.
              </p>
            </div>

            <div className="flex items-center gap-2 flex-wrap justify-end">
              {[
                ['active', `Active (${activeListenings.length})`],
                ['archived', `Archived (${archivedListenings.length})`],
                ['all', `All (${listenings.length})`]
              ].map(([key, label]) => (
                <button
                  key={key}
                  onClick={() => setListeningLibraryFilter(key)}
                  className={`text-xs px-3 py-1.5 rounded-full ${
                    listeningLibraryFilter === key
                      ? 'bg-purple-600 text-white'
                      : 'bg-gray-100 text-gray-500 hover:bg-gray-200'
                  }`}
                >
                  {label}
                </button>
              ))}
            </div>
          </div>

          {filteredListenings.length === 0 ? (
            <p className="text-sm text-gray-400 bg-gray-50 rounded-xl p-4">
              No listening homework found for this filter.
            </p>
          ) : (
            <div className="flex flex-col gap-3">
              {filteredListenings.map(listening =>
                renderListeningHomeworkCard(listening, listening.archived)
              )}
            </div>
          )}
        </div>

        <div className="bg-white border border-gray-100 rounded-2xl p-6 mb-8">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h2 className="font-semibold text-gray-800">
                Writing Homework Library
              </h2>

              <p className="text-xs text-gray-400 mt-1">
                Review Task 1 and Task 2 submissions, manage assignments and archive writing homework.
              </p>
            </div>

            <div className="flex items-center gap-2 flex-wrap justify-end">
              {[
                ['active', `Active (${activeWritings.length})`],
                ['pending', `Pending Review (${pendingReviewWritings.length})`],
                ['archived', `Archived (${archivedWritings.length})`],
                ['all', `All (${writings.length})`]
              ].map(([key, label]) => (
                <button
                  key={key}
                  onClick={() => setWritingLibraryFilter(key)}
                  className={`text-xs px-3 py-1.5 rounded-full ${
                    writingLibraryFilter === key
                      ? 'bg-purple-600 text-white'
                      : 'bg-gray-100 text-gray-500 hover:bg-gray-200'
                  }`}
                >
                  {label}
                </button>
              ))}
            </div>
          </div>

          {filteredWritings.length === 0 ? (
            <p className="text-sm text-gray-400 bg-gray-50 rounded-xl p-4">
              No writing homework found for this filter.
            </p>
          ) : (
            <div className="flex flex-col gap-3">
              {filteredWritings.map(writing =>
                renderWritingHomeworkCard(writing, writing.archived)
              )}
            </div>
          )}
        </div>


          </>
        )}

        {activeTab === 'students' && (
          <>
        <div className="grid grid-cols-1 gap-4">
          {students.length === 0 && (
            <div className="bg-white border border-gray-100 rounded-2xl p-8 text-center text-gray-400 text-sm">
              No students signed up yet.
            </div>
          )}

          {students.map(student => {
            const studentReadings = getStudentReadings(student.id)
            const studentWritings = getStudentWritings(student.id)
            const studentListenings = getStudentListenings(student.id)
            const analytics = getStudentAnalytics(student.id)

            const completedReadingCount = studentReadings.filter(reading =>
              getSubmission(student.id, reading.id)
            ).length

            const completedWritingCount = studentWritings.filter(writing =>
              getWritingSubmission(student.id, writing.id)
            ).length

            const completedListeningCount = studentListenings.filter(listening =>
              getListeningSubmission(student.id, listening.id)
            ).length

            return (
              <div
                key={student.id}
                className="bg-white border border-gray-100 rounded-2xl overflow-hidden"
              >
                <div
                  className="flex items-center justify-between p-5 cursor-pointer hover:bg-gray-50"
                  onClick={() => {
                    const isOpen = selected?.id === student.id
                    setSelected(isOpen ? null : student)
                    setSelectedStudentSection('scores')
                  }}
                >
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-full bg-purple-100 flex items-center justify-center text-purple-600 font-semibold text-sm">
                      {student.name?.charAt(0).toUpperCase()}
                    </div>

                    <div>
                      <p className="text-sm font-medium text-gray-800">
                        {student.name}
                      </p>

                      <p className="text-xs text-gray-400">
                        {student.email}
                      </p>
                    </div>
                  </div>

                  <div className="flex items-center gap-4">
                    {latestScore(student.id) && (
                      <div className="text-right">
                        <p className="text-xs text-gray-400">Latest band</p>
                        <p className="text-lg font-bold text-purple-600">
                          {latestScore(student.id).overall}
                        </p>
                      </div>
                    )}

                    <div className="text-right">
                      <p className="text-xs text-gray-400">Reading done</p>
                      <p className="text-sm font-semibold text-gray-700">
                        {completedReadingCount}/{studentReadings.length}
                      </p>
                    </div>

                    <div className="text-right">
                      <p className="text-xs text-gray-400">Listening done</p>
                      <p className="text-sm font-semibold text-gray-700">
                        {completedListeningCount}/{studentListenings.length}
                      </p>
                    </div>

                    <div className="text-right">
                      <p className="text-xs text-gray-400">Writing done</p>
                      <p className="text-sm font-semibold text-gray-700">
                        {completedWritingCount}/{studentWritings.length}
                      </p>
                    </div>

                    <div className="text-gray-300 text-lg">
                      {selected?.id === student.id ? '▲' : '▼'}
                    </div>
                  </div>
                </div>

                {selected?.id === student.id && (
                  <div className="border-t border-gray-100 p-5">
                    <div className="flex flex-wrap gap-2 mb-6">
                      {[
                        ['scores', '📈 Scores'],
                        ['homework', '📚 Homework'],
                        ['reviews', '✍ Writing Reviews']
                      ].map(([key, label]) => (
                        <button
                          key={key}
                          type="button"
                          onClick={() => setSelectedStudentSection(key)}
                          className={`text-xs px-4 py-2 rounded-xl font-medium ${
                            selectedStudentSection === key
                              ? 'bg-purple-600 text-white'
                              : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
                          }`}
                        >
                          {label}
                        </button>
                      ))}
                    </div>

                    {selectedStudentSection === 'scores' && (
                      <>
                    <div className="mb-8">
                      <h3 className="text-sm font-semibold text-gray-700 mb-3">
                        Log a new score for {student.name}
                      </h3>

                      <div className="grid grid-cols-2 gap-3 mb-3">
                        {['listening', 'reading', 'writing', 'speaking'].map(
                          skill => (
                            <div key={skill}>
                              <label className="text-xs text-gray-400 capitalize mb-1 block">
                                {skill}
                              </label>

                              <input
                                type="number"
                                min="0"
                                max="9"
                                step="0.5"
                                className="w-full border border-gray-200 rounded-xl px-3 py-2 text-sm outline-none focus:border-purple-400"
                                placeholder="e.g. 7.5"
                                value={form[skill]}
                                onChange={e =>
                                  setForm(prev => ({
                                    ...prev,
                                    [skill]: e.target.value
                                  }))
                                }
                              />
                            </div>
                          )
                        )}
                      </div>

                      <div className="mb-3">
                        <label className="text-xs text-gray-400 mb-1 block">
                          Test date
                        </label>

                        <input
                          type="date"
                          className="w-full border border-gray-200 rounded-xl px-3 py-2 text-sm outline-none focus:border-purple-400"
                          value={form.date}
                          onChange={e =>
                            setForm(prev => ({
                              ...prev,
                              date: e.target.value
                            }))
                          }
                        />
                      </div>

                      <button
                        onClick={handleAddScore}
                        className="w-full bg-purple-600 text-white rounded-xl py-2.5 text-sm font-medium hover:bg-purple-700"
                      >
                        Save score for {student.name}
                      </button>
                    </div>

                    {scores[student.id]?.length > 0 && (
                      <div className="mb-8">
                        <div className="flex items-center justify-between mb-3">
                          <h3 className="text-sm font-semibold text-gray-700">
                            Score history
                          </h3>

                          <button
                            onClick={() => handlePrint(student)}
                            className="text-xs bg-gray-100 hover:bg-gray-200 text-gray-600 px-3 py-1.5 rounded-lg"
                          >
                            🖨️ Print scores
                          </button>
                        </div>

                        <div className="flex flex-col gap-2">
                          {scores[student.id].map(score => (
                            <div
                              key={score.id}
                              className="flex items-center justify-between py-2 border-b border-gray-50 last:border-0"
                            >
                              <div>
                                <p className="text-sm text-gray-700">
                                  {score.date}
                                </p>

                                <p className="text-xs text-gray-400">
                                  L:{score.listening} R:{score.reading} W:
                                  {score.writing} S:{score.speaking}
                                </p>
                              </div>

                              <div className="text-lg font-bold text-purple-600">
                                {score.overall}
                              </div>
                            </div>
                          ))}
                        </div>
                      </div>
                    )}

                      </>
                    )}

                    {selectedStudentSection === 'homework' && (
                      <>
                    {analytics.weakest && (
                      <div className="mb-8">
                        <h3 className="text-sm font-semibold text-gray-700 mb-3">
                          Reading Weakness Analytics
                        </h3>

                        <div className="grid grid-cols-2 md:grid-cols-5 gap-3 mb-4">
                          {[
                            ['Matching', analytics.matching],
                            ['Sentence Endings', analytics.sentenceEndings],
                            ['TFNG', analytics.tfng],
                            ['Fill Blank', analytics.fitb],
                            ['Table Completion', analytics.table],
                            ['Note Completion', analytics.note],
                            ['MCQ', analytics.mcq]
                          ].map(([label, value]) => (
                            <div
                              key={label}
                              className="bg-gray-50 rounded-xl p-4 text-center"
                            >
                              <p className="text-xs text-gray-400 mb-1">
                                {label}
                              </p>

                              <p
                                className={`text-xl font-bold ${getAnalyticsColor(
                                  value
                                )}`}
                              >
                                {value ?? '--'}%
                              </p>
                            </div>
                          ))}
                        </div>

                        <div className="bg-purple-50 rounded-xl p-4">
                          <p className="text-xs text-gray-500 mb-1">
                            Weakest Area
                          </p>

                          <p className="font-semibold text-purple-700">
                            {getWeakestLabel(analytics.weakest)}
                          </p>
                        </div>
                      </div>
                    )}

                    <div className="mb-8">
                      <h3 className="text-sm font-semibold text-gray-700 mb-3">
                        Reading homework results
                      </h3>

                      {studentReadings.length === 0 ? (
                        <p className="text-sm text-gray-400 bg-gray-50 rounded-xl p-4">
                          No active reading homework assigned to this student.
                        </p>
                      ) : (
                        <div className="flex flex-col gap-3">
                          {studentReadings.map(reading => {
                            const submission = getSubmission(
                              student.id,
                              reading.id
                            )

                            return (
                              <div
                                key={reading.id}
                                className="border border-gray-100 rounded-xl p-4 bg-gray-50"
                              >
                                <div className="flex items-center justify-between gap-3">
                                  <div>
                                    <p className="text-sm font-medium text-gray-800">
                                      {reading.title}
                                    </p>

                                    <p className="text-xs text-gray-400">
                                      {reading.questions?.length || 0} question
                                      sets · {reading.timeLimit} min
                                    </p>
                                  </div>

                                  {submission ? (
                                    <div className="flex items-center gap-3">
                                      <div className="text-right">
                                        <p className="text-xs text-gray-400">
                                          Band
                                        </p>

                                        <p className="text-lg font-bold text-purple-600">
                                          {submission.result?.band}
                                        </p>
                                      </div>

                                      <div className="text-right">
                                        <p className="text-xs text-gray-400">
                                          Score
                                        </p>

                                        <p className="text-sm font-semibold text-gray-700">
                                          {submission.result?.correct}/
                                          {submission.result?.total}
                                        </p>
                                      </div>

                                      <button
                                        onClick={() =>
                                          setSelectedReview({
                                            student,
                                            reading,
                                            submission
                                          })
                                        }
                                        className="text-xs bg-purple-600 text-white px-3 py-2 rounded-xl hover:bg-purple-700"
                                      >
                                        Review
                                      </button>
                                    </div>
                                  ) : (
                                    <span className="text-xs bg-amber-50 text-amber-600 px-3 py-1.5 rounded-full">
                                      Not done
                                    </span>
                                  )}
                                </div>
                              </div>
                            )
                          })}
                        </div>
                      )}
                    </div>

                      </>
                    )}

                    {selectedStudentSection === 'reviews' && (
                      <>
                    <div>
                      <h3 className="text-sm font-semibold text-gray-700 mb-3">
                        Writing homework results
                      </h3>

                      {studentWritings.length === 0 ? (
                        <p className="text-sm text-gray-400 bg-gray-50 rounded-xl p-4">
                          No active writing homework assigned to this student.
                        </p>
                      ) : (
                        <div className="flex flex-col gap-3">
                          {studentWritings.map(writing => {
                            const submission = getWritingSubmission(
                              student.id,
                              writing.id
                            )

                            return (
                              <div
                                key={writing.id}
                                className="border border-gray-100 rounded-xl p-4 bg-gray-50"
                              >
                                <div className="flex items-center justify-between gap-3">
                                  <div>
                                    <p className="text-sm font-medium text-gray-800">
                                      {writing.title}
                                    </p>

                                    <p className="text-xs text-gray-400">
                                      Task 1 + Task 2 · {writing.timeLimit || 60} min
                                    </p>

                                    {submission && (
                                      <p
                                        className={`text-xs mt-1 font-medium ${
                                          submission.reviewed
                                            ? 'text-green-600'
                                            : 'text-amber-600'
                                        }`}
                                      >
                                        {submission.reviewed
                                          ? `Reviewed — Band ${submission.review?.overall}`
                                          : 'Submitted — Waiting for review'}
                                      </p>
                                    )}
                                  </div>

                                  {submission ? (
                                    <div className="flex items-center gap-3">
                                      <div className="text-right">
                                        <p className="text-xs text-gray-400">
                                          Task 1
                                        </p>

                                        <p className="text-sm font-semibold text-gray-700">
                                          {submission.task1WordCount || 0} words
                                        </p>
                                      </div>

                                      <div className="text-right">
                                        <p className="text-xs text-gray-400">
                                          Task 2
                                        </p>

                                        <p className="text-sm font-semibold text-gray-700">
                                          {submission.task2WordCount || 0} words
                                        </p>
                                      </div>

                                      <button
                                        onClick={() =>
                                          openWritingReview({
                                            student,
                                            writing,
                                            submission
                                          })
                                        }
                                        className={`text-xs px-3 py-2 rounded-xl text-white ${
                                          submission.reviewed
                                            ? 'bg-green-600 hover:bg-green-700'
                                            : 'bg-purple-600 hover:bg-purple-700'
                                        }`}
                                      >
                                        {submission.reviewed ? 'Edit Review' : 'Grade'}
                                      </button>
                                    </div>
                                  ) : (
                                    <span className="text-xs bg-amber-50 text-amber-600 px-3 py-1.5 rounded-full">
                                      Not done
                                    </span>
                                  )}
                                </div>
                              </div>
                            )
                          })}
                        </div>
                      )}
                    </div>
                      </>
                    )}
                  </div>
                )}
              </div>
            )
          })}
        </div>

          </>
        )}

      </div>

      {selectedHomework && (
        <div className="fixed inset-0 bg-black/40 z-50 flex items-center justify-center px-4">
          <div className="bg-white rounded-2xl w-full max-w-xl max-h-[90vh] overflow-y-auto p-6">
            <div className="flex items-start justify-between mb-6">
              <div>
                <h2 className="text-xl font-bold text-gray-900">
                  Manage Assignment
                </h2>

                <p className="text-sm text-gray-400">
                  {selectedHomework.title}
                </p>
              </div>

              <button
                onClick={() => {
                  setSelectedHomework(null)
                  setSelectedHomeworkType(null)
                  setAssignmentDraft([])
                }}
                className="text-sm text-gray-400 hover:text-gray-600"
              >
                Close
              </button>
            </div>

            <div className="flex flex-col gap-3 mb-6">
              {students.map(student => {
                const completed =
                  selectedHomeworkType === 'reading'
                    ? getSubmission(student.id, selectedHomework.id)
                    : selectedHomeworkType === 'listening'
                      ? getListeningSubmission(student.id, selectedHomework.id)
                      : getWritingSubmission(student.id, selectedHomework.id)

                return (
                  <label
                    key={student.id}
                    className="flex items-center justify-between gap-4 border border-gray-100 rounded-xl p-4 cursor-pointer hover:bg-gray-50"
                  >
                    <div className="flex items-center gap-3">
                      <input
                        type="checkbox"
                        checked={assignmentDraft.includes(student.id)}
                        onChange={() => toggleAssignment(student.id)}
                        className="accent-purple-600"
                      />

                      <div>
                        <p className="text-sm font-medium text-gray-800">
                          {student.name}
                        </p>

                        <p className="text-xs text-gray-400">
                          {student.email}
                        </p>
                      </div>
                    </div>

                    {completed ? (
                      <span className="text-xs bg-green-50 text-green-600 px-3 py-1.5 rounded-full">
                        Completed
                      </span>
                    ) : assignmentDraft.includes(student.id) ? (
                      <span className="text-xs bg-purple-50 text-purple-600 px-3 py-1.5 rounded-full">
                        Assigned
                      </span>
                    ) : (
                      <span className="text-xs bg-gray-100 text-gray-500 px-3 py-1.5 rounded-full">
                        Not assigned
                      </span>
                    )}
                  </label>
                )
              })}
            </div>

            <button
              onClick={saveAssignments}
              className="w-full bg-purple-600 text-white rounded-xl py-3 text-sm font-medium hover:bg-purple-700"
            >
              Save assignments
            </button>
          </div>
        </div>
      )}

      {selectedReview && (
        <div className="fixed inset-0 bg-black/40 z-50 flex items-center justify-center px-4">
          <div className="bg-white rounded-2xl w-full max-w-5xl max-h-[90vh] overflow-y-auto p-6">
            <div className="flex items-start justify-between mb-6">
              <div>
                <h2 className="text-xl font-bold text-gray-900">
                  Reading Review
                </h2>

                <p className="text-sm text-gray-400">
                  {selectedReview.student.name} — {selectedReview.reading.title}
                </p>

                <p className="text-sm text-purple-600 font-semibold mt-1">
                  Band {selectedReview.submission.result?.band} ·{' '}
                  {selectedReview.submission.result?.correct}/
                  {selectedReview.submission.result?.total} correct
                </p>
              </div>

              <button
                onClick={() => setSelectedReview(null)}
                className="text-sm text-gray-400 hover:text-gray-600"
              >
                Close
              </button>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <div className="border border-gray-100 rounded-2xl p-5">
                <h3 className="font-semibold text-gray-800 mb-4">
                  Reading Passage
                </h3>

                {selectedReview.reading.passageMode === 'sections' ? (
                  <div className="space-y-6">
                    {selectedReview.reading.paragraphs.map(paragraph => (
                      <div key={paragraph.id}>
                        <h4 className="font-semibold text-gray-900 mb-2">
                          Paragraph {paragraph.letter}
                        </h4>

                        <p className="text-sm text-gray-700 leading-7 whitespace-pre-wrap">
                          {paragraph.text}
                        </p>
                      </div>
                    ))}
                  </div>
                ) : (
                  <p className="text-sm text-gray-700 leading-7 whitespace-pre-wrap">
                    {selectedReview.reading.passage}
                  </p>
                )}
              </div>

              <div className="border border-gray-100 rounded-2xl p-5">
                <h3 className="font-semibold text-gray-800 mb-4">
                  Student Answers
                </h3>

                <div className="flex flex-col gap-4">
                  {selectedReview.reading.questions.map((question, index) => (
                    <div
                      key={question.id}
                      className="border border-gray-100 rounded-xl p-4"
                    >
                      <div className="flex items-center gap-2 mb-3">
                        <span className="text-xs text-gray-400">
                          Q{index + 1}
                        </span>

                        <span className="text-xs bg-purple-50 text-purple-600 px-2 py-1 rounded-full">
                          {question.type === 'matching'
                            ? 'Matching Headings'
                            : question.type === 'sentenceEndings'
                              ? 'Sentence Endings'
                              : question.type === 'tfng'
                              ? 'T/F/NG'
                              : question.type === 'fitb'
                                ? 'Fill blank'
                                : (question.type === 'table' || question.type === 'summary' || question.type === 'note')
                                  ? question.type === 'note' ? 'Note Completion' : 'Table Completion'
                                  : question.mode === 'multi'
                                    ? 'MCQ — Choose TWO'
                                    : 'MCQ'}
                        </span>
                      </div>

                      {question.type === 'matching' ? (
                        <div className="flex flex-col gap-3">
                          {question.paragraphs.map(paragraph => {
                            const correct = isMatchingCorrect(
                              selectedReview.submission,
                              question,
                              paragraph
                            )

                            const userAnswer =
                              selectedReview.submission.answers?.[
                                question.id
                              ]?.[paragraph.letter]

                            const correctAnswer = paragraph.answer

                            return (
                              <div
                                key={paragraph.letter}
                                className={`rounded-xl p-3 border ${
                                  correct
                                    ? 'bg-green-50 border-green-100'
                                    : 'bg-red-50 border-red-100'
                                }`}
                              >
                                <div className="flex justify-between mb-2">
                                  <p className="text-sm font-semibold text-gray-800">
                                    Paragraph {paragraph.letter}
                                  </p>

                                  <p
                                    className={`text-xs font-semibold ${
                                      correct
                                        ? 'text-green-600'
                                        : 'text-red-600'
                                    }`}
                                  >
                                    {correct ? 'Correct' : 'Wrong'}
                                  </p>
                                </div>

                                <p className="text-xs text-gray-500">
                                  Student:
                                </p>

                                <p className="text-sm text-gray-800 mb-2">
                                  {userAnswer
                                    ? `${userAnswer}. ${getHeadingText(
                                        selectedReview.reading,
                                        userAnswer
                                      )}`
                                    : 'No answer'}
                                </p>

                                {!correct && (
                                  <>
                                    <p className="text-xs text-gray-500">
                                      Correct:
                                    </p>

                                    <p className="text-sm font-medium text-green-700">
                                      {correctAnswer}.{' '}
                                      {getHeadingText(
                                        selectedReview.reading,
                                        correctAnswer
                                      )}
                                    </p>
                                  </>
                                )}
                              </div>
                            )
                          })}
                        </div>
                      ) : question.type === 'sentenceEndings' ? (
                        <div>
                          {question.instruction && (
                            <p className="text-sm text-gray-700 mb-4">
                              {question.instruction}
                            </p>
                          )}

                          <div className="bg-gray-50 border border-gray-100 rounded-xl p-4 mb-4">
                            <p className="text-xs font-semibold text-gray-400 uppercase tracking-wider mb-2">
                              Endings
                            </p>

                            <div className="space-y-1">
                              {question.endings?.filter(Boolean).map((ending, endingIndex) => (
                                <p key={endingIndex} className="text-sm text-gray-700">
                                  <span className="font-semibold">
                                    {letters[endingIndex]}.
                                  </span>{' '}
                                  {ending}
                                </p>
                              ))}
                            </div>
                          </div>

                          <div className="flex flex-col gap-3">
                            {question.items?.map(item => {
                              const correct = isSentenceEndingCorrect(
                                selectedReview.submission,
                                question,
                                item
                              )

                              const userAnswer =
                                selectedReview.submission.answers?.[
                                  question.id
                                ]?.[item.id]

                              const correctAnswer = item.answer

                              return (
                                <div
                                  key={item.id}
                                  className={`rounded-xl p-3 border ${
                                    correct
                                      ? 'bg-green-50 border-green-100'
                                      : 'bg-red-50 border-red-100'
                                  }`}
                                >
                                  <div className="flex justify-between mb-2">
                                    <p className="text-sm font-semibold text-gray-800">
                                      {item.sentence}
                                    </p>

                                    <p
                                      className={`text-xs font-semibold ${
                                        correct
                                          ? 'text-green-600'
                                          : 'text-red-600'
                                      }`}
                                    >
                                      {correct ? 'Correct' : 'Wrong'}
                                    </p>
                                  </div>

                                  <p className="text-xs text-gray-500">
                                    Student:
                                  </p>

                                  <p className="text-sm text-gray-800 mb-2">
                                    {userAnswer
                                      ? `${userAnswer}. ${getSentenceEndingText(
                                          question,
                                          userAnswer
                                        )}`
                                      : 'No answer'}
                                  </p>

                                  {!correct && (
                                    <>
                                      <p className="text-xs text-gray-500">
                                        Correct:
                                      </p>

                                      <p className="text-sm font-medium text-green-700">
                                        {correctAnswer}.{' '}
                                        {getSentenceEndingText(
                                          question,
                                          correctAnswer
                                        )}
                                      </p>
                                    </>
                                  )}
                                </div>
                              )
                            })}
                          </div>
                        </div>
                      ) : question.type === 'table' || question.type === 'summary' ? (
                        <div>
                          <p className="text-sm text-gray-700 mb-4">
                            {question.instruction}
                          </p>

                          <div className="overflow-x-auto">
                            <table className="w-full text-sm border border-gray-100 rounded-xl overflow-hidden">
                              <thead>
                                <tr className="bg-gray-100">
                                  {question.columns.map((column, columnIndex) => (
                                    <th
                                      key={columnIndex}
                                      className="p-3 text-left font-semibold text-gray-700 border border-white"
                                    >
                                      {column}
                                    </th>
                                  ))}
                                </tr>
                              </thead>

                              <tbody>
                                {question.rows.map(row => (
                                  <tr key={row.id}>
                                    {row.cells.map((cell, cellIndex) => {
                                      if (cell.type !== 'blank') {
                                        return (
                                          <td
                                            key={cellIndex}
                                            className="p-3 bg-gray-50 border border-white text-gray-700 whitespace-pre-wrap"
                                          >
                                            {cell.text}
                                          </td>
                                        )
                                      }

                                      const key = tableAnswerKey(
                                        question.id,
                                        row.id,
                                        cellIndex
                                      )

                                      const correct = isTableCellCorrect(
                                        selectedReview.submission,
                                        question,
                                        row,
                                        cellIndex
                                      )

                                      return (
                                        <td
                                          key={cellIndex}
                                          className={`p-3 border border-white ${
                                            correct
                                              ? 'bg-green-50'
                                              : 'bg-red-50'
                                          }`}
                                        >
                                          <p className="text-xs text-gray-500 mb-1">
                                            Student:
                                          </p>

                                          <p className="text-sm text-gray-800 mb-2">
                                            {selectedReview.submission.answers?.[
                                              key
                                            ] || 'No answer'}
                                          </p>

                                          {!correct && (
                                            <>
                                              <p className="text-xs text-gray-500 mb-1">
                                                Correct:
                                              </p>

                                              <p className="text-sm font-medium text-green-700">
                                                {[cell.answer, cell.acceptedAnswers].filter(Boolean).join(', ')}
                                              </p>
                                            </>
                                          )}
                                        </td>
                                      )
                                    })}
                                  </tr>
                                ))}
                              </tbody>
                            </table>
                          </div>
                        </div>
                      ) : (
                        <div>
                          <p className="text-sm text-gray-800 mb-3">
                            {question.question}
                          </p>

                          <div
                            className={`rounded-xl p-3 border ${
                              isNormalCorrect(
                                selectedReview.submission,
                                question
                              )
                                ? 'bg-green-50 border-green-100'
                                : 'bg-red-50 border-red-100'
                            }`}
                          >
                            <div className="flex justify-between mb-2">
                              <p className="text-xs text-gray-500">
                                Student answer:
                              </p>

                              <p
                                className={`text-xs font-semibold ${
                                  isNormalCorrect(
                                    selectedReview.submission,
                                    question
                                  )
                                    ? 'text-green-600'
                                    : 'text-red-600'
                                }`}
                              >
                                {isNormalCorrect(
                                  selectedReview.submission,
                                  question
                                )
                                  ? 'Correct'
                                  : 'Wrong'}
                              </p>
                            </div>

                            <p className="text-sm text-gray-800 mb-2">
                              {getAnswerText(
                                question,
                                selectedReview.submission.answers?.[
                                  question.id
                                ]
                              )}
                            </p>

                            {!isNormalCorrect(
                              selectedReview.submission,
                              question
                            ) && (
                              <>
                                <p className="text-xs text-gray-500">
                                  Correct answer:
                                </p>

                                <p className="text-sm font-medium text-green-700">
                                  {question.type === 'mcq' &&
                                  question.mode === 'multi'
                                    ? (question.answers || [])
                                        .map(
                                          letter =>
                                            `${letter}. ${getOptionText(
                                              question,
                                              letter
                                            )}`
                                        )
                                        .join(', ')
                                    : question.type === 'mcq'
                                      ? `${question.answer}. ${getOptionText(
                                          question,
                                          question.answer
                                        )}`
                                      : question.answer}
                                </p>
                              </>
                            )}
                          </div>
                        </div>
                      )}
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {(selectedWritingReview || selectedMockWritingReview) && (() => {
        const reviewTarget = selectedWritingReview || selectedMockWritingReview
        const isMockReview = Boolean(selectedMockWritingReview)
        const reviewTitle = isMockReview
          ? reviewTarget.mock?.title || reviewTarget.submission.mockTitle || 'Mock Test'
          : reviewTarget.writing.title

        const task1Prompt = isMockReview
          ? reviewTarget.mock?.writing?.task1?.prompt || reviewTarget.mock?.task1?.prompt || 'Mock Writing Task 1'
          : reviewTarget.writing.task1?.prompt

        const task1Image = isMockReview
          ? reviewTarget.mock?.writing?.task1?.image || reviewTarget.mock?.task1?.image
          : reviewTarget.writing.task1?.image

        const task2Prompt = isMockReview
          ? reviewTarget.mock?.writing?.task2?.prompt || reviewTarget.mock?.task2?.prompt || 'Mock Writing Task 2'
          : reviewTarget.writing.task2?.prompt

        const task1Answer = isMockReview
          ? getMockTask1Answer(reviewTarget.submission)
          : reviewTarget.submission.task1Answer

        const task2Answer = isMockReview
          ? getMockTask2Answer(reviewTarget.submission)
          : reviewTarget.submission.task2Answer

        const task1WordCount = isMockReview
          ? getMockTask1WordCount(reviewTarget.submission)
          : reviewTarget.submission.task1WordCount

        const task2WordCount = isMockReview
          ? getMockTask2WordCount(reviewTarget.submission)
          : reviewTarget.submission.task2WordCount

        return (
        <div className="fixed inset-0 bg-black/40 z-50 flex items-center justify-center px-4">
          <div className="bg-white rounded-2xl w-full max-w-6xl max-h-[90vh] overflow-y-auto p-6">
            <div className="flex items-start justify-between mb-6">
              <div>
                <h2 className="text-xl font-bold text-gray-900">
                  {isMockReview ? 'Mock Writing Review' : 'Writing Review'}
                </h2>

                <p className="text-sm text-gray-400">
                  {reviewTarget.student.name} — {reviewTitle}
                </p>
              </div>

              <button
                onClick={() => {
                  setSelectedWritingReview(null)
                  setSelectedMockWritingReview(null)
                }}
                className="text-sm text-gray-400 hover:text-gray-600"
              >
                Close
              </button>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <div className="space-y-6">
                <div className="border border-gray-100 rounded-2xl p-5">
                  <div className="flex items-center justify-between mb-4">
                    <h3 className="font-semibold text-gray-800">
                      Task 1 Answer
                    </h3>

                    <span className="text-xs bg-purple-50 text-purple-600 px-3 py-1 rounded-full">
                      {task1WordCount || 0} words
                    </span>
                  </div>

                  <p className="text-xs text-gray-400 mb-3">
                    Prompt:
                  </p>

                  <p className="text-sm text-gray-700 leading-7 whitespace-pre-wrap mb-4 bg-gray-50 rounded-xl p-4">
                    {task1Prompt}
                  </p>

                  {task1Image && (
                    <img
                      src={task1Image}
                      alt="Task 1"
                      className="w-full max-h-[320px] object-contain bg-gray-50 rounded-xl border border-gray-100 mb-4"
                    />
                  )}

                  <p className="text-sm text-gray-800 leading-7 whitespace-pre-wrap">
                    {task1Answer}
                  </p>
                </div>

                <div className="border border-gray-100 rounded-2xl p-5">
                  <div className="flex items-center justify-between mb-4">
                    <h3 className="font-semibold text-gray-800">
                      Task 2 Answer
                    </h3>

                    <span className="text-xs bg-indigo-50 text-indigo-600 px-3 py-1 rounded-full">
                      {task2WordCount || 0} words
                    </span>
                  </div>

                  <p className="text-xs text-gray-400 mb-3">
                    Prompt:
                  </p>

                  <p className="text-sm text-gray-700 leading-7 whitespace-pre-wrap mb-4 bg-gray-50 rounded-xl p-4">
                    {task2Prompt}
                  </p>

                  <p className="text-sm text-gray-800 leading-7 whitespace-pre-wrap">
                    {task2Answer}
                  </p>
                </div>
              </div>

              <div className="border border-gray-100 rounded-2xl p-5 h-fit sticky top-5">
                <h3 className="font-semibold text-gray-800 mb-2">
                  Teacher Evaluation
                </h3>

                <p className="text-xs text-gray-400 mb-5">
                  Use IELTS Writing criteria. Suggested bands are calculated from the rubric, but you can still edit the final band manually.
                </p>

                <div className="bg-purple-50 rounded-2xl p-4 mb-5">
                  <div className="flex items-center justify-between gap-3 mb-3">
                    <div>
                      <p className="text-xs text-gray-500">
                        Suggested Overall
                      </p>

                      <p className="text-2xl font-bold text-purple-700">
                        {suggestedOverallBand || '--'}
                      </p>
                    </div>

                    <button
                      type="button"
                      onClick={useSuggestedBands}
                      className="text-xs bg-purple-600 text-white px-4 py-2 rounded-xl hover:bg-purple-700"
                    >
                      Use Suggested Bands
                    </button>
                  </div>

                  <div className="grid grid-cols-2 gap-3">
                    <div className="bg-white rounded-xl p-3">
                      <p className="text-xs text-gray-400 mb-1">
                        Suggested Task 1
                      </p>

                      <p className="text-lg font-bold text-purple-600">
                        {suggestedTask1Band || '--'}
                      </p>
                    </div>

                    <div className="bg-white rounded-xl p-3">
                      <p className="text-xs text-gray-400 mb-1">
                        Suggested Task 2
                      </p>

                      <p className="text-lg font-bold text-indigo-600">
                        {suggestedTask2Band || '--'}
                      </p>
                    </div>
                  </div>
                </div>

                <div className="border border-gray-100 rounded-2xl p-4 mb-5">
                  <div className="flex items-center justify-between mb-3">
                    <h4 className="font-semibold text-gray-800">
                      Task 1 Rubric
                    </h4>

                    <span className="text-xs bg-purple-50 text-purple-600 px-3 py-1 rounded-full">
                      Academic Task 1
                    </span>
                  </div>

                  <div className="grid grid-cols-2 gap-3">
                    {[
                      ['task1TA', 'Task Achievement'],
                      ['task1CC', 'Coherence & Cohesion'],
                      ['task1LR', 'Lexical Resource'],
                      ['task1GRA', 'Grammar Range & Accuracy']
                    ].map(([key, label]) => (
                      <div key={key}>
                        <label className="text-xs text-gray-400 block mb-1">
                          {label}
                        </label>

                        <input
                          type="number"
                          min="0"
                          max="9"
                          step="0.5"
                          value={writingReviewForm[key]}
                          onChange={e =>
                            setWritingReviewForm(prev => ({
                              ...prev,
                              [key]: e.target.value
                            }))
                          }
                          className="w-full border border-gray-200 rounded-xl px-3 py-2 text-sm outline-none focus:border-purple-400"
                        />
                      </div>
                    ))}
                  </div>
                </div>

                <div className="border border-gray-100 rounded-2xl p-4 mb-5">
                  <div className="flex items-center justify-between mb-3">
                    <h4 className="font-semibold text-gray-800">
                      Task 2 Rubric
                    </h4>

                    <span className="text-xs bg-indigo-50 text-indigo-600 px-3 py-1 rounded-full">
                      Essay
                    </span>
                  </div>

                  <div className="grid grid-cols-2 gap-3">
                    {[
                      ['task2TR', 'Task Response'],
                      ['task2CC', 'Coherence & Cohesion'],
                      ['task2LR', 'Lexical Resource'],
                      ['task2GRA', 'Grammar Range & Accuracy']
                    ].map(([key, label]) => (
                      <div key={key}>
                        <label className="text-xs text-gray-400 block mb-1">
                          {label}
                        </label>

                        <input
                          type="number"
                          min="0"
                          max="9"
                          step="0.5"
                          value={writingReviewForm[key]}
                          onChange={e =>
                            setWritingReviewForm(prev => ({
                              ...prev,
                              [key]: e.target.value
                            }))
                          }
                          className="w-full border border-gray-200 rounded-xl px-3 py-2 text-sm outline-none focus:border-purple-400"
                        />
                      </div>
                    ))}
                  </div>
                </div>

                <div className="grid grid-cols-3 gap-3 mb-5">
                  <div>
                    <label className="text-xs text-gray-400 block mb-1">
                      Task 1 Band
                    </label>

                    <input
                      type="number"
                      min="0"
                      max="9"
                      step="0.5"
                      value={writingReviewForm.task1Band}
                      onChange={e =>
                        setWritingReviewForm(prev => ({
                          ...prev,
                          task1Band: e.target.value
                        }))
                      }
                      placeholder={suggestedTask1Band || ''}
                      className="w-full border border-gray-200 rounded-xl px-3 py-2 text-sm outline-none focus:border-purple-400"
                    />
                  </div>

                  <div>
                    <label className="text-xs text-gray-400 block mb-1">
                      Task 2 Band
                    </label>

                    <input
                      type="number"
                      min="0"
                      max="9"
                      step="0.5"
                      value={writingReviewForm.task2Band}
                      onChange={e =>
                        setWritingReviewForm(prev => ({
                          ...prev,
                          task2Band: e.target.value
                        }))
                      }
                      placeholder={suggestedTask2Band || ''}
                      className="w-full border border-gray-200 rounded-xl px-3 py-2 text-sm outline-none focus:border-purple-400"
                    />
                  </div>

                  <div>
                    <label className="text-xs text-gray-400 block mb-1">
                      Overall
                    </label>

                    <input
                      type="number"
                      min="0"
                      max="9"
                      step="0.5"
                      value={writingReviewForm.overall}
                      onChange={e =>
                        setWritingReviewForm(prev => ({
                          ...prev,
                          overall: e.target.value
                        }))
                      }
                      placeholder={suggestedOverallBand || ''}
                      className="w-full border border-gray-200 rounded-xl px-3 py-2 text-sm outline-none focus:border-purple-400"
                    />
                  </div>
                </div>

                <div className="mb-4">
                  <label className="text-xs text-gray-400 block mb-1">
                    Task 1 Feedback
                  </label>

                  <textarea
                    rows={4}
                    value={writingReviewForm.task1Feedback}
                    onChange={e =>
                      setWritingReviewForm(prev => ({
                        ...prev,
                        task1Feedback: e.target.value
                      }))
                    }
                    className="w-full border border-gray-200 rounded-xl px-3 py-2 text-sm outline-none focus:border-purple-400 resize-none"
                    placeholder="Comment on Task 1..."
                  />
                </div>

                <div className="mb-4">
                  <label className="text-xs text-gray-400 block mb-1">
                    Task 2 Feedback
                  </label>

                  <textarea
                    rows={4}
                    value={writingReviewForm.task2Feedback}
                    onChange={e =>
                      setWritingReviewForm(prev => ({
                        ...prev,
                        task2Feedback: e.target.value
                      }))
                    }
                    className="w-full border border-gray-200 rounded-xl px-3 py-2 text-sm outline-none focus:border-purple-400 resize-none"
                    placeholder="Comment on Task 2..."
                  />
                </div>

                <div className="mb-5">
                  <label className="text-xs text-gray-400 block mb-1">
                    General Feedback
                  </label>

                  <textarea
                    rows={4}
                    value={writingReviewForm.generalFeedback}
                    onChange={e =>
                      setWritingReviewForm(prev => ({
                        ...prev,
                        generalFeedback: e.target.value
                      }))
                    }
                    className="w-full border border-gray-200 rounded-xl px-3 py-2 text-sm outline-none focus:border-purple-400 resize-none"
                    placeholder="Overall writing feedback..."
                  />
                </div>

                <button
                  onClick={isMockReview ? saveMockWritingReview : saveWritingReview}
                  className="w-full bg-purple-600 text-white rounded-xl py-3 text-sm font-medium hover:bg-purple-700"
                >
                  {isMockReview ? 'Save Mock Writing Review' : 'Save Writing Review'}
                </button>
              </div>
            </div>
          </div>
        </div>
        )
      })()}

      {showPasswordModal && (
        <div className="fixed inset-0 bg-black/40 flex items-center justify-center z-50 px-4">
          <div className="bg-white rounded-2xl p-6 w-full max-w-sm">
            <h2 className="font-semibold text-gray-800 mb-4">
              Change Password
            </h2>

            {passwordMsg && (
              <div
                className={`text-sm rounded-xl p-3 mb-4 ${
                  passwordMsg.includes('Error')
                    ? 'bg-red-50 text-red-600'
                    : 'bg-green-50 text-green-600'
                }`}
              >
                {passwordMsg}
              </div>
            )}

            <div className="mb-4">
              <label className="text-xs text-gray-400 mb-1 block">
                New password
              </label>

              <input
                type="password"
                className="w-full border border-gray-200 rounded-xl px-4 py-2.5 text-sm outline-none focus:border-purple-400"
                placeholder="At least 6 characters"
                value={newPassword}
                onChange={e => setNewPassword(e.target.value)}
              />
            </div>

            <div className="flex gap-2">
              <button
                onClick={() => {
                  setShowPasswordModal(false)
                  setPasswordMsg('')
                  setNewPassword('')
                }}
                className="flex-1 py-2.5 rounded-xl border border-gray-200 text-sm text-gray-500"
              >
                Cancel
              </button>

              <button
                onClick={handleChangePassword}
                className="flex-1 py-2.5 rounded-xl bg-purple-600 text-white text-sm font-medium"
              >
                Save
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}